<?php
    global $wpdb;
    if(empty($_GET['review'])){
        global $wp_query;
        $wp_query->set_404();
        status_header( 404 );
        get_template_part( 404 ); exit();
    }
    $GanetetedUrlIs = site_url()."/reviews/?review=".$_GET['review'];
    $results = $wpdb->get_results("SELECT * FROM `".TableName_ReviewSystem()."` WHERE `GeneratedLink` = \"".$GanetetedUrlIs."\"");
    if(count($results)<=0){
        global $wp_query;
        $wp_query->set_404();
        status_header( 404 );
        get_template_part( 404 ); exit();
    }
    // print_r($results);
    // exit;
    
   ?>

<head>


   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <https://hangouts.google.com/call/wznIWgKxucqIEE3Wh_JjAAEMlink rel="profile" href="http://gmpg.org/xfn/11">
   <script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
   <title><?php echo $results[0]->businessName; ?> - Reviews</title>
   <!-- This site is optimized with the Yoast SEO plugin v10.0.1 - https://yoast.com/wordpress/plugins/seo/ -->
   <!-- Admin only notice: this page does not show a meta description because it does not have one, either write it for this page specifically or go into the [SEO - Search Appearance] menu and set up a template. -->
   <link rel="canonical" href="https://getclicked.co/legacy/brockville-review-page/">
   <meta property="og:locale" content="en_US">
   <meta property="og:type" content="article">
  
   <!-- / Yoast SEO plugin. -->
   <link rel="dns-prefetch" href="//s0.wp.com">
   <link rel="dns-prefetch" href="//secure.gravatar.com">
   <link rel="dns-prefetch" href="//use.fontawesome.com">
   <link rel="dns-prefetch" href="//fonts.googleapis.com">
   <link rel="dns-prefetch" href="//s.w.org">
   <link href="https://fonts.gstatic.com" crossorigin="" rel="preconnect">
   <link rel="alternate" type="application/rss+xml" title="Get Clicked » Feed" href="https://getclicked.co/legacy/feed/">
   <link rel="alternate" type="application/rss+xml" title="Get Clicked » Comments Feed" href="https://getclicked.co/legacy/comments/feed/">
   <script type="text/javascript">
      window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/getclicked.co/legacy\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.1.1"}};
      !function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
   </script><script src="https://getclicked.co/legacy/wp-includes/js/wp-emoji-release.min.js?ver=5.1.1" type="text/javascript" defer=""></script>
   <style type="text/css">
      img.wp-smiley,
      img.emoji {
      display: inline !important;
      border: none !important;
      box-shadow: none !important;
      height: 1em !important;
      width: 1em !important;
      margin: 0 .07em !important;
      vertical-align: -0.1em !important;
      background: none !important;
      padding: 0 !important;
      }
   </style>
   <link rel="stylesheet" id="font-awesome-official-css" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" type="text/css" media="all" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
   <link rel="stylesheet" id="font-awesome-official-v4shim-css" href="https://use.fontawesome.com/releases/v5.7.2/css/v4-shims.css" type="text/css" media="all" integrity="sha384-DrjN/yxBJAblffPf548CARk30Xz2Glal7YO5kqQ8c8GHgrAMXZN2ZDTGwV9xTDJF" crossorigin="anonymous">

   
   
   <style id="admin-bar-inline-css" type="text/css">
      .admin-bar {
      position: inherit !important;
      top: auto !important;
      }
      .admin-bar .goog-te-banner-frame {
      top: 32px !important
      }
      @media screen and (max-width: 782px) {
      .admin-bar .goog-te-banner-frame {
      top: 46px !important;
      }
      }
      @media screen and (max-width: 480px) {
      .admin-bar .goog-te-banner-frame {
      position: absolute;
      }
      }
   </style>
   <link rel="stylesheet" id="wp-block-library-css" href="https://getclicked.co/legacy/wp-includes/css/dist/block-library/style.min.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="contact-form-7-css" href="https://getclicked.co/legacy/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="bootstrap-css" href="https://getclicked.co/legacy/wp-content/plugins/oi-portfolio/framework/css/bootstrap.min.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="Siliconfolio-css" href="https://getclicked.co/legacy/wp-content/plugins/oi-portfolio/framework/css/style.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="oi-vs-style-css" href="https://getclicked.co/legacy/wp-content/plugins/oi-shortcodes/vc_extend/vc.css?ver=1" type="text/css" media="all">
   <link rel="stylesheet" id="rs-plugin-settings-css" href="https://getclicked.co/legacy/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.6.4" type="text/css" media="all">
   <style id="rs-plugin-settings-inline-css" type="text/css">
      #rs-demo-id {}
   </style>
   <link rel="stylesheet" id="gravity-fonts-css" href="https://fonts.googleapis.com/css?family=Roboto%3A400%2C700%2C900%2C400italic%2C700italic%2C900italic%7CUbuntu%3A400%2C700%2C900%2C400italic%2C700italic%2C900italic%7CDosis%3A200%2C300%2C400%2C500%2C600%2C700%2C800%26amp%3Bsubset%3Dlatin-ext&amp;subset=latin%2Clatin-ext" type="text/css" media="all">
   <link rel="stylesheet" id="bootstrap-css-css" href="https://getclicked.co/legacy/wp-content/themes/gravity/framework/bootstrap/bootstrap.min.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="remodal-css" href="https://getclicked.co/legacy/wp-content/themes/gravity/framework/css/remodal.css?ver=1" type="text/css" media="all">
   <link rel="stylesheet" id="remodal_theme-css" href="https://getclicked.co/legacy/wp-content/themes/gravity/framework/css/remodal-default-theme.css?ver=1" type="text/css" media="all">
   <link rel="stylesheet" id="gravity-style-css" href="https://getclicked.co/legacy/wp-content/themes/gravity/style.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="font-awesome-css" href="https://getclicked.co/legacy/wp-content/plugins/types/vendor/toolset/toolset-common/res/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0" type="text/css" media="screen">
   <link rel="stylesheet" id="elegant-font-css" href="https://getclicked.co/legacy/wp-content/themes/gravity/framework/css/elegant-font/style.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="lightcase-css" href="https://getclicked.co/legacy/wp-content/themes/gravity/framework/lightcase/lightcase.css?ver=1" type="text/css" media="all">
   <link rel="stylesheet" id="tipso-css" href="https://getclicked.co/legacy/wp-content/themes/gravity/framework/css/tipso.min.css?ver=1" type="text/css" media="all">

   <link rel="stylesheet" id="mc4wp-form-basic-css" href="https://getclicked.co/legacy/wp-content/plugins/mailchimp-for-wp/assets/css/form-basic.min.css?ver=4.3.3" type="text/css" media="all">
   <link rel="stylesheet" id="js_composer_front-css" href="https://getclicked.co/legacy/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.4.5" type="text/css" media="all">
   <link rel="stylesheet" id="bsf-Defaults-css" href="https://getclicked.co/legacy/wp-content/uploads/smile_fonts/Defaults/Defaults.css?ver=5.1.1" type="text/css" media="all">
   <link rel="stylesheet" id="ultimate-style-css" href="https://getclicked.co/legacy/wp-content/plugins/Ultimate_VC_Addons/assets/min-css/style.min.css?ver=3.16.21" type="text/css" media="all">
   <link rel="stylesheet" id="ultimate-animate-css" href="https://getclicked.co/legacy/wp-content/plugins/Ultimate_VC_Addons/assets/min-css/animate.min.css?ver=3.16.21" type="text/css" media="all">
   <link rel="stylesheet" id="ultimate-modal-css" href="https://getclicked.co/legacy/wp-content/plugins/Ultimate_VC_Addons/assets/min-css/modal.min.css?ver=3.16.21" type="text/css" media="all">
   <link rel="stylesheet" id="jetpack_css-css" href="https://getclicked.co/legacy/wp-content/plugins/jetpack/css/jetpack.css?ver=7.1.1" type="text/css" media="all">
   <!--n2css--><script type="text/javascript" src="https://getclicked.co/legacy/wp-includes/js/jquery/jquery.js?ver=1.12.4"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>

   <!--[if lt IE 9]>
   <script type='text/javascript' src='https://getclicked.co/legacy/wp-content/themes/gravity/framework/js/html5min.js?ver=3.7.3'></script>
   <![endif]-->
   <script type="text/javascript">
      /* <![CDATA[ */
      var oi_theme = {"theme_url":"https:\/\/getclicked.co/legacy\/wp-content\/themes\/gravity","home_url":"https:\/\/getclicked.co/legacy\/","ajax_url":"https:\/\/getclicked.co/legacy\/wp-admin\/admin-ajax.php","raw_scroll":"0"};
      /* ]]> */
   </script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/themes/gravity/framework/js/functions.js?ver=1"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/Ultimate_VC_Addons/assets/min-js/ultimate-params.min.js?ver=3.16.21"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/Ultimate_VC_Addons/assets/min-js/modernizr-custom.min.js?ver=3.16.21"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/Ultimate_VC_Addons/assets/min-js/modal-all.min.js?ver=3.16.21"></script>
   <link rel="https://api.w.org/" href="https://getclicked.co/legacy/wp-json/">
   <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://getclicked.co/legacy/xmlrpc.php?rsd">
   <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://getclicked.co/legacy/wp-includes/wlwmanifest.xml">
   <meta name="generator" content="WordPress 5.1.1">
   <link rel="shortlink" href="https://wp.me/PapOti-198">
   <link rel="alternate" type="application/json+oembed" href="https://getclicked.co/legacy/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fgetclicked.co/legacy%2Fbrockville-review-page%2F">
   <link rel="alternate" type="text/xml+oembed" href="https://getclicked.co/legacy/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fgetclicked.co/legacy%2Fbrockville-review-page%2F&amp;format=xml">
   <!-- start Simple Custom CSS and JS -->
   <style type="text/css">
      /* Add your CSS code here.
      For example:
      .example {
      color: red;
      }
      For brushing up on your CSS knowledge, check out http://www.w3schools.com/css/css_syntax.asp
      End of comment */ 
      .far 
      {
      font-size:100px;
      color: #fff;
      background: #a8abb3;
      padding: 35px;
      border-radius: 200px;
      }
      .review-icon-holder, .icon-holder
      {
      text-align:center;
      cursor:pointer;
      }
      .review-icon-holder:hover .far
      {
      background: #298cff;
      }
      .icon-holder
      {
      padding: 10px;
      border: 1px solid rgba(0,0,0,0.2);
      max-width: 240px;
      margin-bottom: 20px!important;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      }
      .icon-holder img
      {
      height: 100px;
      object-fit: contain;
      width:100%;
      }
      .site-holder
      {
      text-align: center; 
      margin: 0 auto;
      }
      .column1_2
      {
      width:49%;
      display:inline-block;
      }
      @media only screen and (min-width:767px)
      {
      .desktop-padding-left50px
      {
      padding-left:50px;
      }
      }
      @media only screen and (max-width:767px)
      {
      .column1_2
      {
      width:100%;
      }
      }
      .good-review-modal
      {
      text-align:center;
      }
    @media only screen and (min-width: 1168px)
    {
        .entry .entry-content > *, .entry .entry-summary > * {
            
        max-width: 100%!important;
        }
    }
    
    /* The classes are associated with modals */
    .overlay-zoomin .vc_btn3-container
    {
        display:none;
    }
    .overlay-zoomin.ult-open .vc_btn3-container
    {
        display:block;
    }
   </style>
   <!-- end Simple Custom CSS and JS -->
   <link rel="dns-prefetch" href="//v0.wordpress.com">
   <link rel="dns-prefetch" href="//i0.wp.com">
   <link rel="dns-prefetch" href="//i1.wp.com">
   <link rel="dns-prefetch" href="//i2.wp.com">
   <style type="text/css">img#wpstats{display:none}</style>
   <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress.">
   <!--[if lte IE 9]>
   <link rel="stylesheet" type="text/css" href="https://getclicked.co/legacy/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen">
   <![endif]-->			
   <style type="text/css">
      /* If html does not have either class, do not show lazy loaded images. */
      html:not( .jetpack-lazy-images-js-enabled ):not( .js ) .jetpack-lazy-image {
      display: none;
      }
   </style>
   <script>
      document.documentElement.classList.add(
      	'jetpack-lazy-images-js-enabled'
      );
   </script>
   
   <style type="text/css" media="screen">
      html { margin-top: 32px !important; }
      * html body { margin-top: 32px !important; }
      @media screen and ( max-width: 782px ) {
      html { margin-top: 46px !important; }
      * html body { margin-top: 46px !important; }
      }
   </style>
   <meta name="generator" content="Powered by Slider Revolution 5.4.6.4 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface.">
   <link rel="icon" href="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2018/10/favicon.png?fit=32%2C32&amp;ssl=1" sizes="32x32">
   <link rel="icon" href="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2018/10/favicon.png?fit=69%2C69&amp;ssl=1" sizes="192x192">
   <link rel="apple-touch-icon-precomposed" href="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2018/10/favicon.png?fit=69%2C69&amp;ssl=1">
   <meta name="msapplication-TileImage" content="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2018/10/favicon.png?fit=69%2C69&amp;ssl=1">
   <script type="text/javascript">function setREVStartSize(e){
      try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
      	if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
      }catch(d){console.log("Failure at Presize of Slider:"+d)}
      };
   </script>

   <link rel="stylesheet" type="text/css" id="wp-custom-css" href="https://getclicked.co/legacy/?custom-css=deddc17117">
   <script type="text/javascript">
      /* <![CDATA[ */
      	var wpNotesIsJetpackClient = true;
      	var wpNotesIsJetpackClientV2 = true;
      	var wpNotesLinkAccountsURL = 'https://getclicked.co/legacy/wp-admin/admin.php?page=jetpack';
      /* ]]> */
   </script>
   <style id="kirki-inline-styles">h3.logo_name{font-family:Dosis, Helvetica, Arial, sans-serif;font-size:32px;font-weight:700;letter-spacing:2px;line-height:32px;text-transform:none;color:#00070a;}p.logo_description{font-family:"Open Sans", Helvetica, Arial, sans-serif;font-size:13px;font-weight:400;line-height:22px;text-transform:none;color:#999;}ul.primary-menu >li> a{font-family:Dosis, Helvetica, Arial, sans-serif;font-size:20px;font-weight:400;letter-spacing:0px;line-height:70px;text-transform:none;color:#ffffff;}ul.primary-menu li a{color:#999999;}ul.primary-menu li a:hover{color:#000000;}ul.primary-menu li a:active, ul.primary-menu li.current-menu-item a, ul.primary-menu li.current-menu-parent > a,body:not(.single-portfolio) ul.primary-menu > li.current_page_parent > a,.primary-menu > li.current-menu-item > a, .primary-menu > li.current-menu-parent > a{color:#000000;}.primary-menu > li.current-menu-item > a::before, .primary-menu > li.current-menu-parent > a::before, body:not(.single-portfolio) .primary-menu > li.current_page_parent > a::before{border-bottom-color:#000000;}.page_title, .oi_c_title a:hover, .entry-header h3 a:hover, .enty-meta > span a:hover, #sidebar .widget a:hover, #sidebar-left .widget a:hover, .footer a:hover, .footer a, #pp-nav .active span, .social-menu a:hover, .social-menu a:hover i, .social-menu a:hover .fa, .oi_testimonial_content_holder h3:before, .oi_testimonial_content_holder h3:after{color:#AEC71E;}.page_title::after,.site-header-menu ul.primary-menu > li.current-menu-item > a, .site-header-menu ul.primary-menu > li.current_page_parent > a, .site-header-menu ul.primary-menu > li.current-menu-parent > a{border-bottom-color:#AEC71E;}#pp-nav .active span{border-color:#AEC71E !important;background:#AEC71E !important;}body{font-family:Nunito, Helvetica, Arial, sans-serif;font-size:18px;font-weight:400;letter-spacing:0px;line-height:24px;text-align:left;text-transform:none;color:#777;}h1{font-family:Nunito, Helvetica, Arial, sans-serif;font-size:34px;font-weight:700;letter-spacing:0px;line-height:1.3;color:#000;}h2{font-family:Nunito, Helvetica, Arial, sans-serif;font-size:28px;font-weight:700;letter-spacing:0px;line-height:1.3;color:#000;}h3{font-family:Nunito, Helvetica, Arial, sans-serif;font-size:24px;font-weight:700;letter-spacing:0px;line-height:1.3;color:#000;}h4{font-family:Nunito, Helvetica, Arial, sans-serif;font-size:18px;font-weight:700;letter-spacing:0px;line-height:1.3;color:#000;}h5{font-family:Nunito, Helvetica, Arial, sans-serif;font-size:16px;font-weight:700;letter-spacing:0px;line-height:1.3;color:#000;}h6{font-family:Nunito, Helvetica, Arial, sans-serif;font-size:14px;font-weight:700;letter-spacing:0px;line-height:1.3;color:#000;}@font-face{font-display:swap;font-family:'Dosis';font-style:normal;font-weight:400;src:local('Dosis Regular'), local('Dosis-Regular'), url(https://fonts.gstatic.com/s/dosis/v8/HhyaU5sn9vOmLzlmC_M.woff) format('woff');}@font-face{font-display:swap;font-family:'Dosis';font-style:normal;font-weight:700;src:local('Dosis Bold'), local('Dosis-Bold'), url(https://fonts.gstatic.com/s/dosis/v8/HhyXU5sn9vOmLzHTLuCLMI0.woff) format('woff');}@font-face{font-display:swap;font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'), local('OpenSans-Regular'), url(https://fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-U1UQ.woff) format('woff');}@font-face{font-display:swap;font-family:'Nunito';font-style:normal;font-weight:400;src:local('Nunito Regular'), local('Nunito-Regular'), url(https://fonts.gstatic.com/s/nunito/v10/XRXV3I6Li01BKof4MQ.woff) format('woff');}@font-face{font-display:swap;font-family:'Nunito';font-style:normal;font-weight:700;src:local('Nunito Bold'), local('Nunito-Bold'), url(https://fonts.gstatic.com/s/nunito/v10/XRXW3I6Li01BKofAjsOkZQ.woff) format('woff');}</style>
   <style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1552927473588{padding-top: 100px !important;}.vc_custom_1552927481544{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1552927430179{margin-bottom: 0px !important;}</style>
   <noscript>
      <style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style>
   </noscript>

   <style>/** Ultimate: Media Responsive **/ @media (max-width: 1199px) { }@media (max-width: 991px)  { }@media (max-width: 767px)  { }@media (max-width: 479px)  { }/** Ultimate: Media Responsive - **/</style>
   <link rel="stylesheet" type="text/css" id="gravatar-card-css" href="https://secure.gravatar.com/dist/css/hovercard.min.css?ver=2019Maraa">
   <link rel="stylesheet" type="text/css" id="gravatar-card-services-css" href="https://secure.gravatar.com/dist/css/services.min.css?ver=2019Maraa">
   <link rel="stylesheet" type="text/css" media="all" href="//static.ctctcdn.com/js/signup-form-widget/current/signup-form-widget.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>


</head>
<body class="page-template-default page page-id-4410 logged-in admin-bar standard_page light_bg no_featured_image wpb-js-composer js-comp-ver-5.4.5 vc_responsive customize-support" style="min-height: 921px;">
   <style type="text/css">html.hs-messages-widget-open.hs-messages-mobile,html.hs-messages-widget-open.hs-messages-mobile body{height:100%!important;overflow:hidden!important;position:relative!important}html.hs-messages-widget-open.hs-messages-mobile body{margin:0!important}#hubspot-messages-iframe-container{display:initial!important;z-index:2147483647;position:fixed!important;bottom:0!important;right:0!important}#hubspot-messages-iframe-container.internal{z-index:1016}#hubspot-messages-iframe-container.internal iframe{min-width:108px}#hubspot-messages-iframe-container .shadow{display:initial!important;z-index:-1;position:absolute;width:0;height:0;bottom:0;right:0;content:""}#hubspot-messages-iframe-container .shadow.internal{display:none!important}#hubspot-messages-iframe-container .shadow.active{width:400px;height:400px;background:radial-gradient(ellipse at bottom right,rgba(29,39,54,.16) 0,rgba(29,39,54,0) 72%)}#hubspot-messages-iframe-container iframe{display:initial!important;width:100%!important;height:100%!important;border:none!important;position:absolute!important;bottom:0!important;right:0!important;background:transparent!important}</style>
   <!-- Google Tag Manager (noscript) -->
   <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K6GWDSX"
      height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
   <!-- End Google Tag Manager (noscript) -->
   <div class="preload page_loaded" style="display: none;"></div>
   <div class="header">
      <div class="logo_holder">
         <a href="https://getclicked.co/legacy/">
         <img class="logo_for_dark_bg" src="https://getclicked.co/legacy/wp-content/uploads/2018/10/Asset-1faq.png" alt="Get Clicked">
         <img class="logo_for_light_bg" src="https://getclicked.co/legacy/wp-content/uploads/2018/10/Asset-2faq-1.png" alt="Get Clicked">
         </a>
      </div>
      <div class="contacts">
         <p></p>
      </div>
   </div>
   <div class="page_featured" style=" background-image:url('')">
      <div class="page_description_over" style="background:  ;opacity:"></div>
      <div class="container">
         <div class="row">
            <div class="col-md-6 col-md-push-3 text-center">
               <div class="page_description">
                  <h1><?php echo  $results[0]->businessName; ?> </h1>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="vc_btn3-container  orange_button vc_btn3-inline hamburger_holder" id="nav-request">
      <a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-classic vc_btn3-color-white" href="https://getclicked.co/legacy/contacts/" title="">REQUEST A CONSULT</a>
   </div>
   <div class="hamburger_holder">
      <span class="icon_menu" aria-hidden="true"></span>
   </div>
   <div class="menu_holder">
      <div class="inner_holder">
         <div class="text-logo">
            <h3 class="logo_name">Get Clicked</h3>
            <p class="logo_description">Get Clicked</p>
         </div>
         <div class="call_extra">
            <i class="fa fa-fw fa-envelope-o" aria-hidden="true"></i>
         </div>
         <nav id="site-navigation" class="main-navigation" role="navigation" aria-label="Primary Menu">
            <div class="menu-primary-menu-container">
               <ul id="menu-primary-menu" class="primary-menu">
                  <li id="menu-item-3973" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-3973"><a href="https://getclicked.co/legacy/">Home</a></li>
                  <li id="menu-item-3931" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3931"><a href="https://getclicked.co/legacy/our-expertise/">Our Expertise</a></li>
                  <li id="menu-item-3316" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3316"><a href="https://getclicked.co/legacy/blog-page/">Get Clicked Insights</a></li>
                  <li id="menu-item-4094" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4094"><a href="http://freetracking.getclicked.co/legacy">Free Tracking Installation</a></li>
                  <li id="menu-item-3972" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3972"><a href="https://getclicked.co/legacy/community/">Community</a></li>
                  <li id="menu-item-3932" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3932"><a href="https://getclicked.co/legacy/contacts/">Contacts</a></li>
               </ul>
            </div>
         </nav>
         <!-- .main-navigation -->
         <div class="menu_footer">
            <p></p>
         </div>
      </div>
      <div class="extra_holder">
         <div class="inner_holder">
            <h3 class="text-center">Drop us a message</h3>
            <p class="text-center">You can use HTML and Shortcodes</p>
         </div>
      </div>
   </div>
   <div class="overlay"></div>
   <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">
         <article id="post-4410">
            <div class="container">
               <div class="entry-content">
                  <!-- Added by Post/Page specific custom CSS plugin, thank you for using! -->
                  <style type="text/css">body
                     {
                     background-color:#a4a4a4;
                     }
                     .bottom_line, .header, .page_featured, .hamburger_holder, #hubspot-messages-iframe-container
                     {
                     display:none!important;
                     }
                     .brockville-button a
                     {
                     border-radius: 0px!important;
                     background: #e5531f !important;
                     color: #fff!important;
                     }
                  </style>
                  <div class="vc_row wpb_row vc_row-fluid vc_custom_1552927473588">
                     <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-has-fill">
                        <div class="vc_column-inner vc_custom_1552927481544">
                           <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element ">
                                 <div class="wpb_wrapper">
                                    <div class="" style="background: #3399ff; color: #fff; text-align: center; padding: 10px;">Thank you for your visit. Please let us know how you found your experience.</div>
                                 </div>
                              </div>
                              <div class="wpb_single_image wpb_content_element vc_align_center">
                                 <figure class="wpb_wrapper vc_figure">
                                    <div class="vc_single_image-wrapper   vc_box_border_grey"><img style="max-height:200px;" src="<?php echo $results[0]->ImageLink;?>" class="vc_single_image-img attachment-full jetpack-lazy-image jetpack-lazy-image--handled" alt=""></div>
                                 </figure>
                              </div>
                              <div class="wpb_text_column wpb_content_element ">
                                 <div class="wpb_wrapper">
                                    <p style="text-align: center;">We’re always striving to improve.  Please let us know how you found your visit at the clinic today.</p>
                                 </div>
                              </div>
                              <div class="vc_row wpb_row vc_inner vc_row-fluid no-margin">
                                 <div class="wpb_column vc_column_container vc_col-sm-3">
                                    <div class="vc_column-inner ">
                                       <div class="wpb_wrapper"></div>
                                    </div>
                                 </div>
                                 <div class="review-icon-holder good-review wpb_column vc_column_container vc_col-sm-3 custom-ult-modal overlay-show" data-class-id="content-5c93ba00a046b9-66609630" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                    <div class="vc_column-inner ">
                                       <div class="wpb_wrapper">
                                          <div class="wpb_raw_code wpb_content_element wpb_raw_html">
                                             <div class="wpb_wrapper">
                                                <i class="far fa-smile"></i>
                                             </div>
                                          </div>
                                          <div class="wpb_text_column wpb_content_element ">
                                             <div class="wpb_wrapper">
                                                <p>Satisfied with my visit.</p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="review-icon-holder bad-review wpb_column vc_column_container vc_col-sm-3 custom-ult-modal overlay-show" data-class-id="content-5c93ba00a070b5-13960981" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                    <div class="vc_column-inner ">
                                       <div class="wpb_wrapper">
                                          <div class="wpb_raw_code wpb_content_element wpb_raw_html">
                                             <div class="wpb_wrapper">
                                                <i class="far fa-frown"></i>
                                                <!--<i class="far fa-thumbs-down"></i>-->
                                             </div>
                                          </div>
                                          <div class="wpb_text_column wpb_content_element ">
                                             <div class="wpb_wrapper">
                                                <p>Dissatisfied with my visit.</p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="wpb_column vc_column_container vc_col-sm-3">
                                    <div class="vc_column-inner ">
                                       <div class="wpb_wrapper"></div>
                                    </div>
                                 </div>
                              </div>
                              <div class="wpb_text_column wpb_content_element  vc_custom_1552927430179">
                                 <div class="wpb_wrapper">
                                    <div class="" style="background: #f5f5f5; height: 44px;"></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="vc_row wpb_row vc_row-fluid">
                     <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                           <div class="wpb_wrapper">
                              <div id="modal-trg-txt-wrap-7088" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a046b9-66609630"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".good-review";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a046b9-66609630");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                              <div id="modal-trg-txt-wrap-7803" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a04c49-34321470"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".google-review";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a04c49-34321470");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                              <div id="modal-trg-txt-wrap-7805" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a04c49-34321475"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".google-review-2";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a04c49-34321475");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                              <div id="modal-trg-txt-wrap-3824" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a050b4-34420112"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".facebook-review";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a050b4-34420112");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                              <div id="modal-trg-txt-wrap-8958" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a054f1-89590665"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".ratemds-review";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a054f1-89590665");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                              <div id="modal-trg-txt-wrap-7286" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a05df6-83603243"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".yelp-review";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a05df6-83603243");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                              <div id="modal-trg-txt-wrap-9936" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a066d2-66462523"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".realself-review";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a066d2-66462523");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                              <div id="modal-trg-txt-wrap-5311" class="ult-modal-input-wrapper ult-adjust-bottom-margin    " data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable">
                                 <span data-class-id="content-5c93ba00a070b5-13960981"></span>
                                 <script type="text/javascript">
                                    (function($){
                                    	$(document).ready(function(){
                                    		var selector = ".bad-review";
                                    		$(selector).addClass("custom-ult-modal overlay-show");
                                    		$(selector).attr("data-class-id", "content-5c93ba00a070b5-13960981");
                                    		$(selector).attr("data-overlay-class", "overlay-zoomin");
                                    		$(selector).attr("data-keypress-control", "keypress-control-enable");
                                    		$(selector).attr("data-overlay-control", "overlay-control-enable");
                                    	});
                                    })(jQuery);
                                 </script>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="vc_row wpb_row vc_row-fluid">
                     <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                           <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element ">
                                 <div class="wpb_wrapper">
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </article>
      </main>
      <!-- .site-main -->
   </div>
   <!-- .content-area -->
   <div class="bottom_line">
      <div class="row">
         <div class="col-md-6">
            <p></p>
         </div>
         <div class="col-md-6">
         </div>
      </div>
   </div>
   <div style="display:none">
   </div>
   <link rel="stylesheet" id="wpcom-notes-admin-bar-css" href="https://s0.wp.com/wp-content/mu-plugins/notes/admin-bar-v2.css?ver=7.1.1-201912" type="text/css" media="all">
   <link rel="stylesheet" id="noticons-css" href="https://s0.wp.com/i/noticons/noticons.css?ver=7.1.1-201912" type="text/css" media="all">
   <script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","188360988737396");fbq("track","PageView");</script>
   <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=188360988737396&amp;ev=PageView&amp;noscript=1"></noscript>


   <script type="text/javascript" src="https://getclicked.co/legacy/wp-includes/js/admin-bar.min.js?ver=5.1.1"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/jetpack/_inc/build/photon/photon.min.js?ver=20130122"></script>
   <script type="text/javascript">
      /* <![CDATA[ */
      var wpcf7 = {"apiSettings":{"root":"https:\/\/getclicked.co/legacy\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
      /* ]]> */
   </script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.1"></script>
   <script type="text/javascript" src="https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201912"></script>
   <script type="text/javascript">
      /* <![CDATA[ */
      var st_sf_theme_plugin = {"theme_url":"https:\/\/getclicked.co/legacy\/wp-content\/plugins\/oi-portfolio\/","ajax_url":"https:\/\/getclicked.co/legacy\/wp-admin\/admin-ajax.php"};
      /* ]]> */
   </script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/oi-portfolio/framework/js/custom_plugin.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/oi-portfolio/framework/js/jquery.waitforimages.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/oi-portfolio/framework/js/isotope.pkgd.min.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/oi-portfolio/framework/js/imagesloaded.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/oi-shortcodes/vc_extend/vc_custom.js"></script>
   <script type="text/javascript" src="https://secure.gravatar.com/js/gprofiles.js?ver=2019Maraa"></script>
   <script type="text/javascript">
      /* <![CDATA[ */
      var WPGroHo = {"my_hash":"0e6ba593a7a669144bc90806d380fc22"};
      /* ]]> */
   </script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/jetpack/modules/wpgroho.js?ver=5.1.1"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/themes/gravity/framework/js/gmap3.min.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/themes/gravity/framework/js/tipso.min.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/themes/gravity/framework/js/remodal.min.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/themes/gravity/framework/lightcase/lightcase.js?ver=1.0.0"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/jetpack/_inc/build/lazy-images/js/lazy-images.min.js?ver=7.1.1"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-includes/js/wp-embed.min.js?ver=5.1.1"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-includes/js/underscore.min.js?ver=1.8.3"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-includes/js/backbone.min.js?ver=1.2.3"></script>
   <script type="text/javascript" src="https://s1.wp.com/wp-content/js/mustache.js?ver=7.1.1-201912"></script>
   <script type="text/javascript" src="https://s1.wp.com/wp-content/mu-plugins/notes/notes-common-v2.js?ver=7.1.1-201912"></script>
   <script type="text/javascript" src="https://s0.wp.com/wp-content/mu-plugins/notes/admin-bar-v2.js?ver=7.1.1-201912"></script>
   <script type="text/javascript" src="https://getclicked.co/legacy/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=5.4.5"></script>
   <!-- start Simple Custom CSS and JS -->
   <style type="text/css">
      /* Add your CSS code here.
      For example:
      .example {
      color: red;
      }
      For brushing up on your CSS knowledge, check out http://www.w3schools.com/css/css_syntax.asp
      End of comment */ 
      /*Hubspot widget*/
      .brand-color-element.second
      {
      background-image: linear-gradient(-225deg,#3399ff 35%,#3399ff)!important;	
      }
   </style>
   <!-- end Simple Custom CSS and JS -->
   <script>	
      jQuery(document).ready(function() {			
      	
      	if (jQuery('#wp-admin-bar-revslider-default').length>0 && jQuery('.rev_slider_wrapper').length>0) {
      		var aliases = new Array();
      		jQuery('.rev_slider_wrapper').each(function() {
      			aliases.push(jQuery(this).data('alias'));
      		});								
      		if(aliases.length>0)
      			jQuery('#wp-admin-bar-revslider-default li').each(function() {
      				var li = jQuery(this),
      					t = jQuery.trim(li.find('.ab-item .rs-label').data('alias')); //text()
      					
      				if (jQuery.inArray(t,aliases)!=-1) {
      				} else {
      					li.remove();
      				}
      			});
      	} else {
      		jQuery('#wp-admin-bar-revslider').remove();
      	}
      });
   </script>
   <!--[if lte IE 8]>
   <script type="text/javascript">
      document.body.className = document.body.className.replace( /(^|\s)(no-)?customize-support(?=\s|$)/, '' ) + ' no-customize-support';
   </script>
   <![endif]-->
   <!--[if gte IE 9]><!-->
   <script type="text/javascript">
      (function() {
      	var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');
      
      			request = true;
      
      	b[c] = b[c].replace( rcs, ' ' );
      	// The customizer requires postMessage and CORS (if the site is cross domain)
      	b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
      }());
   </script>
 
   <div class="ult-overlay content-5c93ba00a046b9-66609630 good-review-modal" data-class="content-5c93ba00a046b9-66609630" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-7021" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-7021 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               <p style="text-align: center;">Thank you! <strong>We need your help.</strong> Would you share your experience on one of these sites?</p>
               <div class="site-holder icon-holder google-review custom-ult-modal overlay-show" data-class-id="content-5c93ba00a04c49-34321470" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable"><img src="https://review.lantryaestheticscenter.com/wp-content/uploads/2019/11/lg.png" width="250" height="100"></div>
               <div class="site-holder icon-holder google-review-2 custom-ult-modal overlay-show" data-class-id="content-5c93ba00a04c49-34321475" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable"><img src="https://thedermatologyoffice.com/review_system/wp-content/uploads/2019/10/lgar.png" width="250" height="100"></div>
               <div class="site-holder icon-holder facebook-review custom-ult-modal overlay-show" data-class-id="content-5c93ba00a050b4-34420112" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable"><img src="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/191qu-233-hago-y-por-qu-233-mary-pedales-16476.png?w=1140&amp;ssl=1" width="1077" height="231"></div>
               <div class="site-holder icon-holder ratemds-review custom-ult-modal overlay-show" data-class-id="content-5c93ba00a054f1-89590665" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable"><img src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/RemoveRateMDs-1.png?w=1140&amp;ssl=1" width="866" height="243"></div>
               <div class="site-holder icon-holder yelp-review custom-ult-modal overlay-show" data-class-id="content-5c93ba00a05df6-83603243" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable"><img src="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/Yelp.png?w=1140&amp;ssl=1" width="1140" height="549"></div>
               <div class="site-holder icon-holder realself-review custom-ult-modal overlay-show" data-class-id="content-5c93ba00a066d2-66462523" data-overlay-class="overlay-zoomin" data-keypress-control="keypress-control-enable" data-overlay-control="overlay-control-enable"><img src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/RealSelf-Primary-Logos.png?w=1140&amp;ssl=1" width="1100" height="244"></div>
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div class="ult-overlay content-5c93ba00a04c49-34321470 container500px" data-class="content-5c93ba00a04c49-34321470" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-7103" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-7103 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               <div class="site-holder" style="max-width: 300px;"><img src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/lg.png?w=1140&amp;ssl=1" width="250" height="100"></div>
               <!--
               <div class="column1_2 desktop-padding-left50px">
                   
                  <p>If you don’t already have a Google account, you should—use it to read and post reviews, as well as access other Google products like Gmail.</p>
                  <p>From our Google listing:</p>
                  <ul>
                     <li>If prompted, sign up or log in</li>
                     <li>Leave your rating and feedback</li>
                     <li>Click <strong>post</strong> to share with others.</li>
                  </ul>
                  
                  <p>You will be prompted to log into your google account. Google reviews should be authentic & will be made public on our listing. Would you be able to let other users know what you liked about your visit?</p>
               </div>
               <div class="column1_2" style="text-align: center;">
                  <p><img style="vertical-align: initial;" src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/modal.jpg?w=1140&amp;ssl=1" width="180" height="240"></p>
               </div>
               -->
               <div class="column1_1">
                   <p style="text-align:center;">You will be prompted to log into your google account. Google reviews should be authentic & will be made public on our listing. Would you be able to let other users know what you liked about your visit?</p>
                   <p style="text-align:center;"><img style="vertical-align: initial;" src="https://getclicked.co/legacy/wp-content/uploads/2019/05/google-review-1.jpg" style="max-width:350px;" ></p>
               </div>
               <p style="text-align: center; color: #999;">Note: This website is not affiliated with or endorsed by Google.</p>
               <div style="text-align: center;">
                   
                 <?php if($results[0]->googleLink) : ?>
                 
                  <div class="vc_btn3-container orange_button wpb_animate_when_almost_visible wpb_fadeIn fadeIn vc_btn3-inline wpb_start_animation animated brockville-button"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-classic vc_btn3-color-white" title="" href="<?php echo $results[0]->googleLink;?>" target="_blank" rel="noopener noreferrer">REVIEW US ON GOOGLE</a></div>
                    <?php else: ?>
                        <script>
                            jQuery('.google-review').hide();
                        </script>
                <?php endif ;?>
               </div>
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div class="ult-overlay content-5c93ba00a04c49-34321475 container500px" data-class="content-5c93ba00a04c49-34321475" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-7105" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-7105 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               <div class="site-holder" style="max-width: 300px;"><img src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/lg.png?w=1140&amp;ssl=1" width="250" height="100"></div>
               <!--
               <div class="column1_2 desktop-padding-left50px">
                   
                  <p>If you don’t already have a Google account, you should—use it to read and post reviews, as well as access other Google products like Gmail.</p>
                  <p>From our Google listing:</p>
                  <ul>
                     <li>If prompted, sign up or log in</li>
                     <li>Leave your rating and feedback</li>
                     <li>Click <strong>post</strong> to share with others.</li>
                  </ul>
                  
                  <p>You will be prompted to log into your google account. Google reviews should be authentic & will be made public on our listing. Would you be able to let other users know what you liked about your visit?</p>
               </div>
               <div class="column1_2" style="text-align: center;">
                  <p><img style="vertical-align: initial;" src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/modal.jpg?w=1140&amp;ssl=1" width="180" height="240"></p>
               </div>
               -->
               <div class="column1_1">
                   <p style="text-align:center;">You will be prompted to log into your google account. Google reviews should be authentic & will be made public on our listing. Would you be able to let other users know what you liked about your visit?</p>
                   <p style="text-align:center;"><img style="vertical-align: initial;" src="https://getclicked.co/legacy/wp-content/uploads/2019/05/google-review-1.jpg" style="max-width:350px;" ></p>
               </div>
               <p style="text-align: center; color: #999;">Note: This website is not affiliated with or endorsed by Google.</p>
               <div style="text-align: center;">
                   
                 <?php if($meta_google_link_2) : ?>
                 
                  <div class="vc_btn3-container orange_button wpb_animate_when_almost_visible wpb_fadeIn fadeIn vc_btn3-inline wpb_start_animation animated brockville-button"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-classic vc_btn3-color-white" title="" href="<?php echo $meta_google_link_2;?>" target="_blank" rel="noopener noreferrer">REVIEW US ON GOOGLE</a></div>
                    <?php else: ?>
                        <script>
                            jQuery('.google-review-2').hide();
                        </script>
                <?php endif ;?>
               </div>
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div class="ult-overlay content-5c93ba00a050b4-34420112 container500px" data-class="content-5c93ba00a050b4-34420112" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-9416" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-9416 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               <div class="site-holder" style="max-width: 300px;"><img src="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/191qu-233-hago-y-por-qu-233-mary-pedales-16476.png?w=1140&amp;ssl=1" width="1077" height="231"></div>
               <p style="max-width: 700px;text-align: center;margin: 20px auto;">Facebook allows you to connect with friends and to review businesses – it would be appreciated if you can share your experience with others on the platform. You must be logged into Facebook in order to leave a review. </p>
                  
               <div class="column1_2 desktop-padding-left50px" style="vertical-align:top;">
                  <p>Steps to review:</p>
                  <ul>
                     <li class="">Find the review tab on the left</li>
                     <li class="">Click "Leave a rating" </li>
                     <li class="">Provide your opinion</li>
                     
                  </ul>
               </div>
               <div class="column1_2" style="text-align: center;">
                  <p><img style="vertical-align: initial;max-height: 250px;" src="https://getclicked.co/legacy/wp-content/uploads/2019/05/facebook.jpg" style="width:100%;"></p>
               </div>
               <p style="text-align: center; color: #999;">Note: This website is not affiliated with or endorsed by Facebook.</p>
               <div style="text-align: center;">
                <?php if($results[0]->fbLink) :?>
                  <div class="vc_btn3-container orange_button wpb_animate_when_almost_visible wpb_fadeIn fadeIn vc_btn3-inline wpb_start_animation animated brockville-button"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-classic vc_btn3-color-white" title="" href="<?php echo $results[0]->fbLink;?>" target="_blank" rel="noopener noreferrer">REVIEW US ON FACEBOOK</a></div>
               <?php else: ?>
                        <script>
                            jQuery('.facebook-review').hide();
                        </script>
               
               <?php endif;?>
               </div>
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div class="ult-overlay content-5c93ba00a054f1-89590665 container500px" data-class="content-5c93ba00a054f1-89590665" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-7851" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-7851 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               <div class="site-holder" style="max-width: 300px;"><img src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/RemoveRateMDs-1.png?w=1140&amp;ssl=1" width="866" height="243"></div>
               <div class="column1_2 desktop-padding-left50px">
                  <p>RateMDs is “the original Doctor Ratings site.” They collect simple ratings and reviews of doctors.</p>
                  <p><strong>You don’t need an account to post a review.</strong> From our listing:</p>
                  <ul>
                     <li class="">Scroll down to the “Rate Dr. [Your Doctor]” section.</li>
                     <li class="">Rate your experience with us in each category, and include any detailed comments.</li>
                     <li class="">Add optional details and submit your ratings</li>
                  </ul>
               </div>
               <div class="column1_2" style="text-align: center;">
                  <p><img style="vertical-align: initial;" src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/modal-2.jpg?w=1140&amp;ssl=1" width="180" height="240"></p>
               </div>
               <p style="text-align: center; color: #999;">Note: This website is not affiliated with or endorsed by RateMDs.</p>
               <div style="text-align: center;">
                  <?php if($results[0]->RateMDsLink) :?>  
                   
                  <div class="vc_btn3-container orange_button wpb_animate_when_almost_visible wpb_fadeIn fadeIn vc_btn3-inline wpb_start_animation animated brockville-button"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-classic vc_btn3-color-white" title="" href="<?php echo $results[0]->RateMDsLink;?>" target="_blank" rel="noopener noreferrer">REVIEW US ON RATEMDS</a></div>
               <?php else: ?>
                        <script>
                            jQuery('.ratemds-review').hide();
                        </script>
               
                <?php endif;?>
               </div>
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div class="ult-overlay content-5c93ba00a05df6-83603243 container500px" data-class="content-5c93ba00a05df6-83603243" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-1348" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-1348 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               <div class="site-holder" style="max-width: 300px;"><img src="https://i1.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/Yelp.png?w=1140&amp;ssl=1" width="1140" height="549"></div>
               <div class="column1_2 desktop-padding-left50px">
                  <p>Yelp connects people with great local businesses.</p>
                  <p><strong>You do need an account to post a review on the site.  From our listing: </strong> </p>
                  <ul>
                     <li class="">Hit the “write a review” button.</li>
                     <li class="">Leave us 5 stars (if that’s how you feel, make it as honest as possible)</li>
                     <li class="">Talk about your experience with us.</li>
                  </ul>
               </div>
               <div class="column1_2" style="text-align: center;">
                  <p><img style="vertical-align: initial;" src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/modal-2.jpg?w=1140&amp;ssl=1" width="180" height="240"></p>
               </div>
               <p style="text-align: center; color: #999;">Note: This website is not affiliated with or endorsed by Yelp.</p>
               <div style="text-align: center;">
                   
                <?php if($results[0]->YelpLink) :?>  
                  <div class="vc_btn3-container orange_button wpb_animate_when_almost_visible wpb_fadeIn fadeIn vc_btn3-inline wpb_start_animation animated brockville-button"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-classic vc_btn3-color-white" title="" href="<?php echo $results[0]->YelpLink;?>" target="_blank" rel="noopener noreferrer">REVIEW US ON YELP</a></div>
                    <?php else: ?>
                        <script>
                            jQuery('.yelp-review').hide();
                        </script>
                <?php endif;?>  
               </div>
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div class="ult-overlay content-5c93ba00a066d2-66462523 container500px" data-class="content-5c93ba00a066d2-66462523" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-8350" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-8350 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               <div class="site-holder" style="max-width: 300px;"><img src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/RealSelf-Primary-Logos.png?w=1140&amp;ssl=1" width="1100" height="244"></div>
               <div class="column1_2 desktop-padding-left50px">
                  <p>RateMDs is “the original Doctor Ratings site.” They collect simple ratings and reviews of doctors.</p>
                  <p><strong>You don’t need an account to post a review.</strong> From our listing:</p>
                  <ul>
                     <li class="">Scroll down to the “Rate Dr. [Your Doctor]” section.</li>
                     <li class="">Rate your experience with us in each category, and include any detailed comments.</li>
                     <li class="">Add optional details and submit your ratings</li>
                  </ul>
               </div>
               <div class="column1_2" style="text-align: center;">
                  <p><img style="vertical-align: initial;" src="https://i2.wp.com/getclicked.co/legacy/wp-content/uploads/2019/03/modal-2.jpg?w=1140&amp;ssl=1" width="180" height="240"></p>
               </div>
               <p style="text-align: center; color: #999;">Note: This website is not affiliated with or endorsed by RealSelf.</p>
               <div style="text-align: center;">
                  <?php if($results[0]->RealSelfLink) :?>   
                    <div class="vc_btn3-container orange_button wpb_animate_when_almost_visible wpb_fadeIn fadeIn vc_btn3-inline wpb_start_animation animated brockville-button"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-classic vc_btn3-color-white" title="" href="<?php echo $results[0]->RealSelfLink;?>" target="_blank" rel="noopener noreferrer">REVIEW US ON REALSELF</a></div>
                <?php else: ?>
                        <script>
                            jQuery('.realself-review').hide();
                        </script>
                <?php endif;?>  
               </div>
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div class="ult-overlay content-5c93ba00a070b5-13960981 good-review-modal" data-class="content-5c93ba00a070b5-13960981" id="button-click-overlay" style="background: rgba(255, 255, 255, 0);">
      <div class="ult_modal ult-fade ult-medium">
         <div id="ult-modal-wrap-8321" class="ult_modal-content ult-hide" style="border-style:solid;border-width:2px;border-radius:0px;border-color:#333333;">
            <div data-ultimate-target="#ult-modal-wrap-8321 .ult_modal-body" data-responsive-json-new="{&quot;font-size&quot;:&quot;&quot;,&quot;line-height&quot;:&quot;&quot;}" class="ult_modal-body ult-responsive ult-html" style="">
               <p></p>
               
               <form action="javascript:void(0)" style="max-width: 600px; margin: 0 auto;" id="BadReviewForm">
                   <p style="text-align: center;">We strive for 100% customer satisfaction. If we fell short, please tell us more so we can address your concerns.</p>
                  <p style="text-align: left;" >Your Name</p>
                  <p><input type="text" required placeholder="Your Name"  name="UserName"></p>
                  <p style="text-align: left;" name="UserMessage">Message</p>
                  <p><textarea style="margin: 0px; height: 108px; width: 100%;" cols="50" rows="4" required placeholder="Write your message."  name="UserMessage"></textarea></p>
                  <input type="hidden" name="bsUserMail" value="<?php echo $results[0]->businessEmail; ?>">
                  <button type="submit" class="btn btn-primary">Submit</button>
               </form>
               <p id="AfterMailSendSuccess"></p>
               <script>
                   
                   jQuery("#BadReviewForm").validate({
                      submitHandler:function(){
                                var postValue = "action=FormReviewSystemBadReviewGive&parem=FormReviewSystemBadReviewGiveUser&"+jQuery("#BadReviewForm").serialize();
                                console.log(postValue);
                                 jQuery.post("<?php echo admin_url("admin-ajax.php"); ?>",postValue,function(response){
                                        console.log(response);
                                      
                                      var jsonData = jQuery.parseJSON(response);
                                     console.log(jsonData);
                                    if(jsonData.status == "success"){
                                        jQuery("#BadReviewForm").hide();
                                         jQuery("#AfterMailSendSuccess").html(" Mail successfully sent ");
                                    }else{
                                       location.reload();
                                    }
                                    
                              });
                      },
                    });
                                   
               </script>
               
               <p>
               </p>
            </div>
         </div>
      </div>
      <div class="ult-overlay-close top-right" style="width:80px;height:80px; ">
         <div class="ult-overlay-close-inside">Close</div>
      </div>
   </div>
   <div id="hubspot-messages-iframe-container" style="width: 108px; height: 92px;">
      <div class="shadow"></div>
      <iframe src="https://app.hubspot.com/conversations-visitor/5414761/threads/utk/74cbe49d38ee4d189c57dd5798ae783b?uuid=5e6d07c8e0a34966ae76d5386762cb45&amp;mobile=false&amp;mobileSafari=false&amp;open=false&amp;hideWelcomeMessage=true&amp;domain=getclicked.co/legacy&amp;inApp53=false&amp;messagesUtk=74cbe49d38ee4d189c57dd5798ae783b&amp;url=https%3A%2F%2Fgetclicked.co/legacy%2Fbrockville-review-page%2F&amp;inline=false&amp;hubspotUtk=74cbe49d38ee4d189c57dd5798ae783b"></iframe>
   </div>
</body>