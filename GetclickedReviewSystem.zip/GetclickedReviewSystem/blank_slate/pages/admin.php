<div class="wrap">
	<h1><?php esc_html_e( 'Hello World!', 'blank-slate' ); ?></h1>
</div>
