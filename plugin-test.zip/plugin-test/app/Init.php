<?php

namespace App;

class Init 
{
    public static function init()
    {
        self::adminPluginAfterActivate();
        self::adminMenuAdd();
    }

    /**
     * The code that runs during plugin after activation.
    */
    public function adminPluginAfterActivate()
    {
        $admin_menu = new \App\Feature\AfterActivate();
        $admin_menu->action();
    }

    /**
     * Creating a admin menu
    */
    public function adminMenuAdd()
    {
        $admin_menu = new \App\Feature\AdminMenu();
        $admin_menu->action();
    }
}
