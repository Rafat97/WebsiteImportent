<?php

namespace App\Basic;

class Activate 
{

    public static function activate()
    {
        // exit( wp_redirect( admin_url( 'admin.php?page=test-plugin' ) ) );
    }
    
}
