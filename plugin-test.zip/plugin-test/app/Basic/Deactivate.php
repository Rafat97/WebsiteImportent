<?php

namespace App\Basic;

class Deactivate 
{
    public static function deactivate()
    {
        # code...
    }
    
}