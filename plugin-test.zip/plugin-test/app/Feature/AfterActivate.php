<?php

namespace App\Feature;

class AfterActivate 
{
    public function action() {
		add_action( 'activated_plugin', array( $this, 'after_activate' ) );
	}

    public function after_activate($plugin)
    {
        if( $plugin == PLUGIN ) {
            exit( wp_redirect( admin_url( 'admin.php?page=test-plugin' ) ) );
        }
    }
    
}
