<?php 

namespace App\Feature;

class AdminMenu
{
	public function action() {
		add_action( 'admin_menu', array( $this, 'add_admin_pages' ) );
	}

	public function add_admin_pages() {
        add_menu_page( 
            'Test Plugin', 
            'Test Menu', 
            'manage_options',
            'test-plugin', 
            array( $this, 'admin_index' ), 
            'dashicons-menu' 
        );
	}

	public function admin_index() {
		echo "Test Menu";
	}
}
