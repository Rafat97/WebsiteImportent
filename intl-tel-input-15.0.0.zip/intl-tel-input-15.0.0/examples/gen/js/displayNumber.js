var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1549804213570" // just for formatting/placeholders etc
});
