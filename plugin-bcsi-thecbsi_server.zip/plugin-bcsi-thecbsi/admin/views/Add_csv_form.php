

    <div id="app_form">
        <div>

        <validation-observer ref="observer" v-slot="{ handleSubmit }">
            <b-form @submit.stop.prevent="handleSubmit(onSubmit)">
                <validation-provider
                name="Name"
                rules="required|min:2"
                v-slot="validationContext"
                >

                    <b-form-group 
                    id="example-input-group-1" 
                    label="Enter Name" 
                    label-for="example-input-1"
                    description="Please enter a name . Ex : bcsi-2022 or BCSI 2022 or BCSI-2022 or bcsi 2022"
                    >
                        <b-form-input
                        id="example-input-1"
                        name="example-input-1"
                        v-model="form.name"
                        placeholder="Ex : BCSI-2022"
                        :state="getValidationState(validationContext)"
                        aria-describedby="input-1-live-feedback"
                        ></b-form-input>

                        <b-form-invalid-feedback id="input-1-live-feedback">{{ validationContext.errors[0] }}</b-form-invalid-feedback>
                    </b-form-group>

                </validation-provider>

                <validation-provider
                name="CSV File"
                rules="required|ext:csv"
                v-slot="validationContext"
                >
                
                    <b-form-group 
                    id="example-input-group-2" 
                    label="Upload CSV file" 
                    label-for="input-2"
                    description="Please upload csv file"
                    >
                        <b-form-file
                            v-model="form.file"
                            :state="getValidationState(validationContext)"
                            placeholder="Choose a file "
                            drop-placeholder="Drop file here..."
                            accept=".csv"
                            ></b-form-file>

                        <!-- <div class="mt-3">Selected file: {{ form.file ? form.file.name : '' }}</div> -->

                        <b-form-invalid-feedback id="input-1-live-feedback">{{ validationContext.errors[0] }}</b-form-invalid-feedback>
                    </b-form-group>

                </validation-provider>
                <b-button type="submit"  :disabled="submit_disabled" variant="primary">Submit</b-button>
                <b-button class="ml-2"  :disabled="submit_disabled" @click="onReset">Reset</b-button>
                <div class="text-center my-5"><h3>{{ form.upload_csv_percentage }}% uploaded</h3></div>
            </b-form>
        </validation-observer>

        </div>
    </div>

    <script>
        var app = new Vue({
        el: '#app_form',
        data: function(){
            return {
                form: {
                    name: null,
                    file: null,
                    upload_csv_percentage: 0,
                },
                submit_disabled: false,
                show: true,
                value: '',
                url : "<?php echo admin_url("admin-ajax.php")."?action=CsvUploadFormSubmit" ?>",
            }
        },
        methods: {
            getValidationState({ dirty, validated, valid = null }) {
                return dirty || validated ? valid : null;
            },
            onSubmit() {
                this.submit_disabled = true;
                const formData = new FormData();
                formData.append("name", this.form.name);
                formData.append("file", this.form.file);
                console.log(this.form.file)
                axios.post(
                    this.url,
                    formData,
                    {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        },
                        onUploadProgress: function(progressEvent) {
                            var percentCompleted = Math.round(
                            (progressEvent.loaded * 100) / progressEvent.total
                            );
                            // console.log(percentCompleted);
                            this.form.upload_csv_percentage = percentCompleted;
                        }.bind(this)
                    }
                    )
                .then(function (response) {
                    var res = response.data ;
                    this.submit_disabled = false;
                    console.log(res );
                    if (res.status == "error") {
                        alert(res.message)
                    }else if(res.status == "success"){
                        alert(res.message)
                    }
                    location.reload();
                })
                .catch(function ( error ) {
                    this.submit_disabled = false;
                    console.log(error.response);
                    alert(error.response.data)
                });
                // alert(JSON.stringify(this.form))
            },
            onReset() {
                this.submit_disabled = false;
                this.form.name = ''
                this.form.file = ''
                
                // Trick to reset/clear native browser form validation state
                this.show = false
                this.$nextTick(() => {
                this.show = true
                this.$refs.observer.reset();
                })
            }
            }
        })
    </script>
