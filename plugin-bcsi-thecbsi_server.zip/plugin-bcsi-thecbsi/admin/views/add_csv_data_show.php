<div>

<?php 
$tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
$results = $wpdb->get_results( 
    "SELECT * FROM `$tableName` " 
 );
?>
    <div class="text-center my-4">
        <h1>Data show</h1>
    </div>

    <div id="app_show_data">
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>id</th>
                <th>Name</th>
                <th>Slug</th>
                <th>Download File</th>
                <th>Delete</th>
                <th>Start date</th>
            </tr>
        </thead>
        <tbody>
        <?php  foreach ($results as $key => $value) : ?>
            <tr>
                <td><?php echo $value->id ?></td>
                <td><?php echo $value->name ?></td>
                <td><?php echo $value->slug ?></td>
                <td>
                    <a href="<?php echo $value->csv_url ?>" target="_blank" rel="noopener noreferrer">
                        <button class="btn btn-primary" id="">Download File</button>
                    </a>
                </td>
                <td>
                <b-form @submit.stop.prevent="onSubmitDelete(<?php echo $value->id;?>)">
                    <button class="btn btn-danger">Delete</button>
                </b-form>
                </td>
                <td><?php echo $value->created_at ?></td>
            </tr>
        <?php endforeach;?>
        </tbody>
        <tfoot>
            <tr>
                <th>id</th>
                <th>Name</th>
                <th>Slug</th>
                <th>Download File</th>
                <th>Delete</th>
                <th>Start date</th>
            </tr>
        </tfoot>
    </table>
    </div>
</div>



<script>
        var app = new Vue({
        el: '#app_show_data',
        data: function(){
            return {
                form: {
                    name: null,
                    file: null,
                },
                show: true,
                value: '',
                url : "<?php echo admin_url("admin-ajax.php")."?action=CsvUploadFormDeleteSubmit" ?>",
            }
        },
        methods: {
            getValidationState({ dirty, validated, valid = null }) {
                return dirty || validated ? valid : null;
            },
            onSubmitDelete(id) {
                
                const formData = new FormData();
                formData.append("deleteId", id);
                axios.post(
                    this.url,
                    formData,
                    {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                    }
                    )
                .then(function (response) {
                    var res = response.data ;
                    if (res.status == "error") {
                        alert(res.message)
                    }else if(res.status == "success"){
                        alert(res.message)
                    }
                    location.reload();
                })
                .catch(function (error) {
                    console.log(error.response);
                });
                // alert(JSON.stringify(this.form))
            },
            onReset() {
                this.form.name = ''
                this.form.file = ''
                
                // Trick to reset/clear native browser form validation state
                this.show = false
                this.$nextTick(() => {
                this.show = true
                this.$refs.observer.reset();
                })
            }
            }
        })
    </script>


<script>
$(document).ready(function() {
    $('#example').DataTable({
        responsive: true,
    });
});
</script>
