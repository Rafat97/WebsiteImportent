<?php
 global $wpdb;
 $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
 $results = $wpdb->get_row( 
     $wpdb->prepare("SELECT * FROM `{$tableName}` WHERE 	id=%d", $current_selected_csv_id) 
  );
  if(empty($results)){
    global $wp_query;
    $wp_query->set_404();
    status_header( 404 );
    get_template_part( 404 ); exit();
  }

    
// print_r($results)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-vue@latest/dist/bootstrap-vue.css" >
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <script src="https://unpkg.com/babel-polyfill@latest/dist/polyfill.min.js" ></script>
    <script src="https://unpkg.com/bootstrap-vue@latest/dist/bootstrap-vue.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- jsdelivr -->
    <script src="https://cdn.jsdelivr.net/npm/vee-validate@latest/dist/vee-validate.full.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vee-validate@latest/dist/rules.umd.min.js"></script>


    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.21/af-2.3.5/b-1.6.2/b-colvis-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/cr-1.5.2/fc-3.3.1/fh-3.1.7/kt-2.5.2/r-2.2.5/rg-1.1.2/rr-1.2.7/sc-2.0.2/sp-1.1.1/sl-1.3.1/datatables.min.css"/>
 
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.21/af-2.3.5/b-1.6.2/b-colvis-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/cr-1.5.2/fc-3.3.1/fh-3.1.7/kt-2.5.2/r-2.2.5/rg-1.1.2/rr-1.2.7/sc-2.0.2/sp-1.1.1/sl-1.3.1/datatables.min.js"></script>
    <script>

        const VeeValidate = window.VeeValidate;
        const VeeValidateRules = window.VeeValidateRules;

        const ValidationProvider = VeeValidate.ValidationProvider;
        const ValidationObserver = VeeValidate.ValidationObserver;

        VeeValidate.extend('required', VeeValidateRules.required);
        VeeValidate.extend('min', VeeValidateRules.min);
        VeeValidate.extend('ext', VeeValidateRules.ext);

        Vue.component('ValidationProvider', ValidationProvider);
        Vue.component('ValidationObserver', ValidationObserver);

    </script>
</head>
<body style="background:#f1f1f1">
<div class="container">
    <div class="my-5 text-center">
        <h1> CSV Result (<?php echo $results->name; ?>)</h1>
    </div>
    <div>
 
    <?php 
    if (!empty($_GET['form_type']) && $_GET['form_type'] == 'edit_form') {
        include_once "csv_table_result_datatable_edit.php"; 
    } else {
        include_once "csv_table_result_datatable_show.php";
    }
    ?>

    </div>
<?php  
// $file = fopen($results->csv_dir,"r");
// $fields = fgetcsv($file);
// fclose($file);
// $table = new \App\Database\BCSI_THECBSI_csv_to_sql_dymanic($results->slug); 
// $sql=$table->getCreateTableSqlQuary($fields);
// $table->TableCreate($sql);
// $columns_name = $table->TableColumnName();
// $columns_name = $table->TableInsertCsv($results->csv_dir); //insert from csv

// echo $results->csv_dir;
// $table = new \App\Database\BCSI_THECBSI_csv_to_sql_dymanic($results->slug); 
// $table->TableInsertCsv($results->csv_dir);

//insert single
// $file = fopen($results->csv_dir,"r");
// while(! feof($file))
// {
//     $insert=array();
//     $from_csv=fgetcsv($file);
//     foreach ($from_csv as $key => $value) {
//         $insert[$columns_name[$key]] = $value;
//     }
//     $table->TableInsert($insert);
// }
// fclose($file);
?>
</div>

</body>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</html>