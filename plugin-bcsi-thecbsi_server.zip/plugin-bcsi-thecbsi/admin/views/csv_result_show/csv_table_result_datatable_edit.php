<div>

    <?php
    $slug= $results->slug;
    $table_name= $results->table_name;
    $table_column_user_column = unserialize($results->table_column_user_column);
    $dynamic_data_id = $_GET['data_edited_id'];
    $dynamic_data_select = $wpdb->get_row( 
        $wpdb->prepare("SELECT * FROM `{$table_name}` WHERE `id` = %d",$dynamic_data_id) 
    );
    // print_r($dynamic_data_select);
    if (empty($dynamic_data_select)) {
       echo "No data found in `{$table_name}` .";
       exit;
    }
    ?>

    <div class="text-center my-4">
        <h1>Data Edit</h1>
    </div>

    <div id="app_form_edit_dynamic_data">

    <validation-observer ref="observer" v-slot="{ handleSubmit }">
        <b-form @submit.stop.prevent="handleSubmit(onSubmit)">
            <validation-provider
            name="Name"
            rules="required|min:2"
            v-slot="validationContext"
            >
            <?php foreach ($table_column_user_column['table_header'] as $key => $value) : ?>
                <b-form-group 
                id="example-input-group-1" 
                label="<?php echo $table_column_user_column['user_header'][$key] ?>" 
                label-for="example-input-1"
                >
                    <b-form-input
                    id="example-input-1"
                    name="example-input-1"
                    v-model="form.<?php echo $value ?>"
                    placeholder="Ex : BCSI-2022"
                    :state="getValidationState(validationContext)"
                    aria-describedby="input-1-live-feedback"
                    ></b-form-input>

                    <b-form-invalid-feedback id="input-1-live-feedback">{{ validationContext.errors[0] }}</b-form-invalid-feedback>
                
            <?php endforeach;?>    
                </b-form-group>

            </validation-provider>


            <b-button type="submit"  :disabled="submit_disabled" variant="primary">Submit</b-button>
          
        </b-form>
        
    </validation-observer>
    <?php global $wp;
$back_page_url = home_url("wp-admin/admin.php?page=".$_GET['page'] ); ?>
<br><br>
    <a href="<?php echo $back_page_url; ?>">
        <b-button type="submit"  :disabled="submit_disabled" variant="primary">Back</b-button>
    </a>
        
    </div>
</div>

<script>
        var app = new Vue({
        el: '#app_form_edit_dynamic_data',
        data: function(){
            return {
                form: {
                    <?php foreach ($table_column_user_column['table_header'] as $key => $value) : ?>
                    <?php echo $value ?>: "<?php echo $dynamic_data_select->{$value} ?>",
                    <?php endforeach;?>    
                   
                    upload_csv_percentage: 0,
                },
                submit_disabled: false,
                show: true,
                value: '',
                url : "<?php echo admin_url("admin-ajax.php")."?action=BCSI_plug_DatabaseDynamicDataEdit" ?>",
            }
        },
        methods: {
            getValidationState({ dirty, validated, valid = null }) {
                return dirty || validated ? valid : null;
            },
            onSubmit() {
                this.submit_disabled = true;
                const formData = new FormData();
                <?php foreach ($table_column_user_column['table_header'] as $key => $value) : ?>
                formData.append("<?php echo $value ?>", this.form.<?php echo $value?>);
                <?php endforeach;?>    
                formData.append("editedId", "<?php echo $dynamic_data_id ;?>");
                formData.append("tableName", '<?php echo $table_name?>');
                axios.post(
                    this.url,
                    formData,
                    {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        },
                    }
                    )
                .then(function (response) {
                    var res = response.data ;
                    this.submit_disabled = false;
                    console.log(res );
                    if (res.status == "error") {
                        alert(res.message)
                    }else if(res.status == "success"){
                        alert(res.message)
                    }
                    location.reload();
                })
                .catch(function ( error ) {
                    this.submit_disabled = false;
                    console.log(error.response);
                    alert(error.response.data)
                });
                // alert(JSON.stringify(this.form))
            },
            onReset() {
                this.submit_disabled = false;
                this.form.name = ''
                this.form.file = ''
                
                // Trick to reset/clear native browser form validation state
                this.show = false
                this.$nextTick(() => {
                this.show = true
                this.$refs.observer.reset();
                })
            }
            }
        })
    </script>