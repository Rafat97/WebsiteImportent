<div>

    <?php
    $slug= $results->slug;
    $table_name= $results->table_name;
    $table_column_user_column = unserialize($results->table_column_user_column);
    // print_r($table_column_user_column);
    ?>

    <div class="text-center my-4">
        <h1>Data show</h1>
    </div>

    <div id="app_show_data">
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                <?php foreach ($table_column_user_column['user_header'] as $key => $value) : ?>
                    <th><?php echo $value; ?></th>
                <?php endforeach;?>
                <th><?php echo "Edit"; ?></th>
                <th><?php echo "Delete"; ?></th>
                </tr>
            </thead>
            <tbody>
                <!-- <?php  
                global $wpdb;
                $dynamin_database_data = $wpdb->get_results( 
                    $wpdb->prepare("SELECT * FROM `{$table_name}` ") 
                 );
                foreach ($dynamin_database_data as $key => $database_data) : ?>
                <tr>
                   
                    <?php foreach ($table_column_user_column['table_header'] as $key => $column_name) : ?>
                        <td><?php echo $database_data->{$column_name}; ?></td>
                    <?php endforeach;?>
                </tr>
                <?php endforeach;?> -->
            </tbody>
            <tfoot>
                <tr>
                <?php foreach ($table_column_user_column['user_header'] as $key => $value) : ?>
                    <th><?php echo $value; ?></th>
                <?php endforeach;?>
                 <th><?php echo "Edit"; ?></th>
                 <th><?php echo "Delete"; ?></th>
                </tr>
            </tfoot>
        </table>
    </div>
    
</div>

<script>
$(document).ready(function() {
    $('#example').DataTable({
        //dom: 'Bfrtip',
        // buttons: [
        //     'csv', 'pdf', 'print'
        // ],
        responsive: true,
        processing: true,
        serverSide: true,
        ajax: {
            cache: true,
            url: "<?php echo \App\Api\BCSI_THECBSI_bcsi_result::getUrl().$results->id ?>", // json datasource
            type: 'get',  // method  , by default get

        },
        columnDefs: [
            {targets: 1,data: null,defaultContent: "<button>Select Image ID</button>"} ,  
        ],
        columns: [
            <?php foreach ($table_column_user_column['table_header'] as $key => $value) :
                echo ' { "data": "'.$value.'" },';
            endforeach; ?>
            {
                data: "id",
                className: "center",
                searchable: false,
                sortable: false,
                render: (function (id, type, full, meta) {
                            var current_url = "<?php echo $_GET['page'] ?>";
                            var dom_edit = 
                            "<form action='' method='get'>"+
                            "<input type='hidden' name='page' value='"+current_url+"'>"+
                            "<input type='hidden' name='form_type' value='edit_form'>"+
                            "<input type='hidden' name='data_edited_id' value="+id+">"+
                            "<button class='btn btn-primary' type='submit'>Edit</button>"+
                            "</form>";     

                            return        dom_edit;
                        }),

            },
            {
                data: "id",
                className: "center",
                searchable: false,
                sortable: false,
                render: (function (id, type, full, meta) {
                            return "<button class='btn btn-danger' type='submit' onclick='onClickDelete("+id+")'>Delete</button>";            
                        }),

            }
            // { 
            //     "data": "id",
            //     "searchable": false,
            //     "sortable": false,
            //     "render": function (id, type, full, meta) {
            //                                 return '<a href="/user/userdata/'+id+'"><i class="fa fa-pencil"></i></a>';
            //                             } 
            // },
        ],
        
        
    });
});
function onClickDelete(id) {
    var sure = confirm("Are you sure ? ");
    if (!sure) {
      return false;  
    }
    if (id && sure) {
        var url = "<?php echo admin_url("admin-ajax.php")."?action=BCSI_plug_DatabaseDynamicDataDelete" ?>"
        const formData = new FormData();
        formData.append("deletedId", id);
        formData.append("tableName", '<?php echo $table_name?>');
        axios.post(
                        url,
                        formData,
                        {
                            headers: {
                                'Content-Type': 'multipart/form-data'
                            }
                        }
                        )
                    .then(function (response) {
                        var res = response.data ;
                        if (res.status == "error") {
                            alert(res.message)
                        }else if(res.status == "success"){
                            alert(res.message)
                        }
                        location.reload();
                    })
                    .catch(function ( error ) {
                        console.log(error.response);
                        alert(error.response.data)
                    });
    }
    else{
        alert("Please check the `id` (onClickDelete)")
    }
}
</script>
<script>

var app = new Vue({
        el: '#app_show_data',
        data: function(){
            return {
                form: {
                    name: null,
                    file: null,
                    upload_csv_percentage: 0,
                },
                submit_disabled: false,
                show: true,
                value: '',
                url : "<?php echo admin_url("admin-ajax.php")."?action=CsvUploadFormSubmit" ?>",
            }
        },
        methods: {}
        })
</script>