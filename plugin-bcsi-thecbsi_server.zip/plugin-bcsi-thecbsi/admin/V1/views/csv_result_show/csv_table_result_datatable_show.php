<div>

    <?php
    $slug= $results->slug;
    $table_name= \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableName();
    $table_column_user_column = unserialize($results->table_column_user_column);
    // $results = $wpdb->get_row( 
    //     $wpdb->prepare("SELECT * FROM `{$tableName}` WHERE 	id=%d", $current_selected_csv_id) 
    // );
    // print_r($table_column_user_column);
    ?>

    <div class="text-center my-4">
        <h1>Data show</h1>
    </div>

    <div id="app_show_data">
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                <!-- <th><?php echo "ID"; ?></th> -->
                <th><?php echo "First Name"; ?></th>
                <th><?php echo "Last Name"; ?></th>
                <th><?php echo "City"; ?></th>
                <th><?php echo "State or Province"; ?></th>
                <th><?php echo "Country"; ?></th>
                <th><?php echo "Website"; ?></th>
                <th><?php echo "Edit"; ?></th>
                <th><?php echo "Delete"; ?></th>
                
                </tr>

            </thead>

            <tbody>
                <?php  
                global $wpdb;
                $dynamin_database_data = $wpdb->get_results( 
                    "SELECT * FROM `{$table_name}` "
                 );
                foreach ($dynamin_database_data as $key => $database_data) : ?>
                <tr>
                    <!-- <td><?php echo $database_data->id; ?></td> -->
                    <td><?php echo $database_data->first_name; ?></td>
                    <td><?php echo $database_data->last_name; ?></td>
                    <td><?php echo $database_data->city; ?></td>
                    <td><?php echo $database_data->state_or_province; ?></td>
                    <td><?php echo $database_data->country; ?></td>
                    <td><?php echo $database_data->website; ?></td>
                    
                    <td>
                        <form action='' method='get'>
                            <input type='hidden' name='page' value='<?php echo $_GET['page'] ?>'>
                            <input type='hidden' name='form_type' value='edit_form'>
                            <input type='hidden' name='data_edited_id' value="<?php echo $database_data->id ?>">
                            <button class='btn btn-primary' type='submit'>Edit</button>
                        </form>   
                    </td>
                    <td>
                        <button class='btn btn-danger' type='submit' onclick='onClickDelete(<?php echo $database_data->id ?>)'>Delete</button>
                    </td> 
                </tr>
                <?php endforeach;?>

            </tbody>
            <tfoot>
                <tr>
                    <!-- <th><?php echo "ID"; ?></th> -->
                    <th><?php echo "First Name"; ?></th>
                    <th><?php echo "Last Name"; ?></th>
                    <th><?php echo "City"; ?></td>
                    <th><?php echo "State or Province"; ?></th>
                    <th><?php echo "Country"; ?></th>
                    <th><?php echo "Website"; ?></th>
                    <th><?php echo "Edit"; ?></th>
                    <th><?php echo "Delete"; ?></th>
                </tr>
            </tfoot>
        </table>
    </div>
    
</div>

<script>
$(document).ready(function() {
    
    $('#example tfoot th').each( function () {
        var title = $(this).text();
        if (title.toUpperCase()  == "Edit".toUpperCase()  || title.toUpperCase()  == "Delete".toUpperCase() ) {
            
        }else{
            $(this).html( '<input type="text" placeholder="Search '+title+'" style="width:100px" />' );
        }
    } );

    $('#example').DataTable({
        initComplete: function () {
            // Apply the search
            this.api().columns().every( function () {
                var that = this;
 
                $( 'input', this.footer() ).on( 'keyup change clear', function () {
                    if ( that.search() !== this.value ) {
                        that
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
        },
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'csv',
                exportOptions: {
                    columns: [ 0, 1, 2, 3, 4, 5 ]
                }
            },
        ],
        responsive: true,
    });
});
function onClickDelete(id) {
    var sure = confirm("Are you sure ? ");
    if (!sure) {
      return false;  
    }
    if (id && sure) {
        var url = "<?php echo admin_url("admin-ajax.php")."?action=BCSI_plug_DatabaseDynamicDataDelete" ?>"
        const formData = new FormData();
        formData.append("deletedId", id);
        formData.append("tableName", '<?php echo $table_name?>');
        axios.post(
                        url,
                        formData,
                        {
                            headers: {
                                'Content-Type': 'multipart/form-data'
                            }
                        }
                        )
                    .then(function (response) {
                        var res = response.data ;
                        if (res.status == "error") {
                            alert(res.message)
                        }else if(res.status == "success"){
                            alert(res.message)
                        }
                        location.reload();
                    })
                    .catch(function ( error ) {
                        console.log(error.response);
                        alert(error.response.data)
                    });
    }
    else{
        alert("Please check the `id` (onClickDelete)")
    }
}
</script>
<script>

var app = new Vue({
        el: '#app_show_data',
        data: function(){
            return {
                form: {
                    name: null,
                    file: null,
                    upload_csv_percentage: 0,
                },
                submit_disabled: false,
                show: true,
                value: ''
            }
        },
        methods: {}
        })
</script>