<?php

function bcsi_thecbsi_convert_slug($value)
{
    $slug = trim($value); // trim the string
    $slug= preg_replace('/[^a-zA-Z0-9 -]/','',$slug ); // only take alphanumerical characters, but keep the spaces and dashes too...
    $slug= str_replace(' ','_', $slug); // replace spaces by dashes
    $slug= strtolower($slug);  // make it lowercase

    return $slug;
}

function bcsi_thecbsi_table_column_name($table_name)
{
    global $wpdb;

    $tablename = $table_name;
    $cols = $wpdb->get_col("DESC `{$tablename}` ",0);
    
    return $cols ;
}
