<?php

namespace App;

class BCSI_THECBSI_Init_V1 
{
    public static function init()
    {
        self::adminMenuAdd_v1();
        self::ajaxAdd_v1();
        self::apiAdd_v1();
    }
    
    public static function adminMenuAdd_v1()
    {
        $admin_menu = new \App\Feature\V1\BCSIAdminMenu_V1();
        $admin_menu->action();
    }
    
    public static function ajaxAdd_v1()
    {
        $csv_upload = new \App\Ajax\V1\BCSI_THECBSI_WpAjax_csv_upload();
        $csv_upload->action();
        
        $dynamic_data = new \App\Ajax\V1\BCSI_THECBSI_WpAjax_database_dynamic_data();
        $dynamic_data->action();
    }
    public static function apiAdd_v1()
    {
        $api = new \App\Api\BCSI_THECBSI_bcsi_result();
        $api->action();
    }

}
