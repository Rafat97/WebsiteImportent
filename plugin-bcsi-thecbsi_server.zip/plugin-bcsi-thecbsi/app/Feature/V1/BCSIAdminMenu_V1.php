<?php 

namespace App\Feature\V1;

class BCSIAdminMenu_V1
{

	public function action() {
		add_action( 'admin_menu', array( $this, 'add_admin_pages' ) );
	}

	public function add_admin_pages() {
        add_menu_page( 
            'BCSI', 
            'BCSI Menu', 
            'manage_options',
            'bcsi-thecbsi-plugin', 
            array( $this, 'admin_index' ), 
            'dashicons-vault' ,
            50
        );

        add_submenu_page(
             'bcsi-thecbsi-plugin',__("Add CSV BCSI"),__("Add CSV"),'manage_options', 'bcsi-thecbsi-plugin', array( $this, 'admin_index' )
        );
        global $wpdb;
        $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
        $results = $wpdb->get_row( 
            $wpdb->prepare("SELECT * FROM `{$tableName}` WHERE 	id=%d",1) 
         );
         if(!empty($results)){
            add_submenu_page( 
                'bcsi-thecbsi-plugin', __("BCSI Info"),__("BCSI Info"),'manage_options', 'bcsi-thecbsi-plugin-bcsi-result-preview', array( $this, 'admin_BCSI_info_page' )
            );
        }
        add_submenu_page( 
            'bcsi-thecbsi-plugin', __("Plugin Info"),__("Plugin Info"),'manage_options', 'bcsi-thecbsi-plugin-info', array( $this, 'admin_plugin_info' )
        );
        

	}

	public function admin_index() {
		include_once BCSI_THECBSI_PLUGIN_PATH.'admin/V1/views/csv_upload/add_csv.php';
    }

    public function admin_plugin_info() {
        echo "plugin info";
    }
    public function admin_BCSI_info_page() {
        include_once BCSI_THECBSI_PLUGIN_PATH.'admin/V1/views/csv_result_show/csv_table_result_show.php';
    }
}
