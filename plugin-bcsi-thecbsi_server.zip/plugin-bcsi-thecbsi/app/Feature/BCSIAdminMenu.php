<?php 

namespace App\Feature;

class BCSIAdminMenu
{

    protected $csv_views_id = array();

	public function action() {
		add_action( 'admin_menu', array( $this, 'add_admin_pages' ) );
	}

	public function add_admin_pages() {
        add_menu_page( 
            'BCSI', 
            'BCSI Menu', 
            'manage_options',
            'bcsi-thecbsi-plugin', 
            array( $this, 'admin_index' ), 
            'dashicons-vault' ,
            50
        );

        add_submenu_page(
             'bcsi-thecbsi-plugin',__("Add CSV BCSI"),__("Add CSV"),'manage_options', 'bcsi-thecbsi-plugin', array( $this, 'admin_index' )
        );
        add_submenu_page( 
            'bcsi-thecbsi-plugin', __("Plugin Info"),__("Plugin Info"),'manage_options', 'bcsi-thecbsi-plugin-info', array( $this, 'admin_plugin_info' )
        );

        global $wpdb;
        $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
        $results = $wpdb->get_results( 
            "SELECT * FROM `$tableName` " 
        );
        foreach ($results as $key => $value) {
            // $this->csv_submenu_slug = $value->slug;
            $view_hook_name = add_submenu_page( 
                'bcsi-thecbsi-plugin', __($value->name),__($value->name),'manage_options', 
                'bcsi-thecbsi-plugin-csv-table-'.__($value->slug)
                //."&id=12"
                ,array( $this, 'admin_CSV_table' )
            );
            $this->csv_views_id[$view_hook_name] = $value->id;
        }
	}

	public function admin_index() {
		include_once BCSI_THECBSI_PLUGIN_PATH.'admin/views/Add_csv.php';
    }

    public function admin_plugin_info() {
        echo "plugin info";
    }

    public function admin_CSV_table() {

        $current_selected_csv_id = $this->csv_views_id[current_filter()];
        include_once BCSI_THECBSI_PLUGIN_PATH.'admin/views/csv_result_show/csv_table_result_show.php';

	}
}
