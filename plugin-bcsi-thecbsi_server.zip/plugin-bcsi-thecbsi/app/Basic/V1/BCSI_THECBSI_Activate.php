<?php

namespace App\Basic\V1;

class BCSI_THECBSI_Activate 
{

    public static function activate()
    {
        \App\Database\BCSI_THECBSI_csv_upload::TableCreate();
        \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableCreate();
        // exit( wp_redirect( admin_url( 'admin.php?page=test-plugin' ) ) );
    }
    
}
