<?php

namespace App\Basic\V1;

class BCSI_THECBSI_Deactivate 
{
    public static function deactivate()
    {
        \App\Database\BCSI_THECBSI_csv_upload::TableDelete();
        \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableDelete();
    }
    
}