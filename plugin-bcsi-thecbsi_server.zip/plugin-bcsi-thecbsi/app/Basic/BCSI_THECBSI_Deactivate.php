<?php

namespace App\Basic;

class BCSI_THECBSI_Deactivate 
{
    public static function deactivate()
    {
        global $wpdb;
        $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
        $results_from_table = $wpdb->get_results( 
                $wpdb->prepare("SELECT * FROM `{$tableName}`") 
        );
        foreach ($results_from_table as  $value) {
            $sql = "DROP TABLE IF EXISTS `".$value->table_name."`";
            $wpdb->query($sql) or die(json_encode(array("status"=>"error","message"=>"Error to delete $results_from_table->table_name database ")));

        }

        \App\Database\BCSI_THECBSI_csv_upload::TableDelete();
    }
    
}