<?php

namespace App\Basic;

class BCSI_THECBSI_Activate 
{

    public static function activate()
    {
        \App\Database\BCSI_THECBSI_csv_upload::TableCreate();
        // exit( wp_redirect( admin_url( 'admin.php?page=test-plugin' ) ) );
    }
    
}
