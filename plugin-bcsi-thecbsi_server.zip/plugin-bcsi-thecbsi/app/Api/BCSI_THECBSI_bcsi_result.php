<?php

namespace App\Api;

//https://www.codexworld.com/datatables-server-side-processing-with-php-mysql/
//https://datatables.net/examples/server_side/object_data.html
class BCSI_THECBSI_bcsi_result 
{

    public function action() {
		add_action( 'rest_api_init', function () {
            register_rest_route( 'plugin-bcsi-thecbsi/v1', '/datatable/(?P<id>\d+)', array(
              'methods' => 'GET',
              'callback' => array( $this, 'my_awesome_func' ) ,
              'args' => array(
                'id' => array(
                  'validate_callback' => 'is_numeric'
                ),
                'columns' => array(
                    'required' => true,
                ),
                'draw' => array(
                    'required' => true,
                )
              ),
            ) );
          } );
    }
    function my_awesome_func( $data ) {
        try {
            global $wpdb;
            // return $_REQUEST;
            $id = $data['id'];
            $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
            $results = $wpdb->get_row( 
                $wpdb->prepare("SELECT * FROM {$tableName} WHERE 	id=%d",  $id) 
            );
            if (empty($results)) {
                $error = array('status'=>'error' ,'message'=>"No data found" );
                return new \WP_REST_Response( $error ,404 );
            }

            $sql_dynamic_table = "SELECT * FROM `{$results->table_name}` "
                ." ".$this->order($_REQUEST , $_REQUEST['columns'],$results)
                ." ".$this->limit( $_REQUEST , $_REQUEST['columns']);

            $sql_dynamic_table_count = "SELECT COUNT(`id`) as total FROM `{$results->table_name}` ";
        
            $results_dynamic_table = $wpdb->get_results( 
                $wpdb->prepare($sql_dynamic_table) 
            ); 
            $results_dynamic_table_count = $wpdb->get_row( 
                $wpdb->prepare($sql_dynamic_table_count) 
            ); 
            $response = array(
                "draw" => $_REQUEST['draw'],
                "recordsTotal" => $results_dynamic_table_count->total,
                "recordsFiltered"=> $results_dynamic_table_count->total,
                "data"            => $results_dynamic_table,
            );
            return new \WP_REST_Response( $response , 200 );
        }catch (Exception $e) {
            return new WP_Error( ' plugin-bcsi-thecbsi api error', __( "$e->getMessage()") );
        }
    }

    function limit( $request, $columns )
	{
		$limit = '';
		if ( isset($request['start']) && $request['length'] != -1 ) {
			$limit = "LIMIT ".intval($request['start']).", ".intval($request['length']);
		}
		return $limit;
	}

    function order ( $request, $columns , $table_data)
	{
		$order = '';

		if ( isset($request['order']) && count($request['order']) ) {

            $orderBy = array();
            $table_column_name = unserialize($table_data->table_column_user_column)['table_header'];

			for ( $i=0, $ien=count($request['order']) ; $i<$ien ; $i++ ) {
				$columnIdx = intval($request['order'][$i]['column']);
				$requestColumn = $request['columns'][$columnIdx];


				if ( $requestColumn['orderable'] == 'true' ) {
					$dir = $request['order'][$i]['dir'] === 'asc' ?
						'ASC' :
						'DESC';
                   
					$orderBy[] = '`'.$table_column_name[$columnIdx].'` '.$dir;
                }
                
			}

			if ( count( $orderBy ) ) {
				$order = 'ORDER BY '.implode(', ', $orderBy);
			}
		}

		return $order;
    }
    
    function data_output ( $columns, $data )
	{
		$out = array();

		for ( $i=0, $ien=count($data) ; $i<$ien ; $i++ ) {
			$row = array();

			for ( $j=0, $jen=count($columns) ; $j<$jen ; $j++ ) {
				$column = $columns[$j];

				// Is there a formatter?
				if ( isset( $column['formatter'] ) ) {
                    if(empty($column['db'])){
                        $row[ $column['dt'] ] = $column['formatter']( $data[$i] );
                    }
                    else{
                        $row[ $column['dt'] ] = $column['formatter']( $data[$i][ $column['db'] ], $data[$i] );
                    }
				}
				else {
                    if(!empty($column['db'])){
                        $row[ $column['dt'] ] = $data[$i][ $columns[$j]['db'] ];
                    }
                    else{
                        $row[ $column['dt'] ] = "";
                    }
				}
			}

			$out[] = $row;
		}

		return $out;
	}


    public static function getUrl(){
        $url = site_url()."/wp-json/plugin-bcsi-thecbsi/v1/datatable/";
        return $url;
    }

}
