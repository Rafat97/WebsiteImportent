<?php

namespace App;

class BCSI_THECBSI_Init 
{
    public static function init()
    {
        if (BCSI_THECBSI_PLUGIN_VERSION == "2.0.0") {
            self::adminMenuAdd_v2();
            self::ajaxAdd_v2();
            self::apiAdd_v2();
        }

    
    }

    /**
     * Creating a admin menu
    */
    public static function adminMenuAdd_v2()
    {
        $admin_menu = new \App\Feature\BCSIAdminMenu();
        $admin_menu->action();
    }

    public static function ajaxAdd_v2()
    {
        $csv_upload = new \App\Ajax\BCSI_THECBSI_WpAjax_csv_upload();
        $csv_upload->action();

        $dynamic_data = new \App\Ajax\BCSI_THECBSI_WpAjax_database_dynamic_data();
        $dynamic_data->action();
    }

    public static function apiAdd_v2()
    {
        $api = new \App\Api\BCSI_THECBSI_bcsi_result();
        $api->action();
    }

}
