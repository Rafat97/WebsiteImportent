<?php


namespace App\Ajax;


class BCSI_THECBSI_WpAjax_csv_upload
{
    public $file_ext_support = array(
        "text/csv",
        "application/vnd.ms-excel",
    );
	public function action() {
        add_action("wp_ajax_CsvUploadFormSubmit", array( $this, 'CsvUploadFormSubmit' ));
        add_action("wp_ajax_CsvUploadFormDeleteSubmit", array( $this, 'wp_ajax_CsvUploadFormDeleteSubmit' ));
	}

	public function CsvUploadFormSubmit() {
        try {
            global $wpdb;
            if ($this->CsvUploadFormValidation()) {
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                $uploadedfile = $_FILES['file'];
                $upload_overrides = array( 'test_form' => false );
                
                $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
                if ( $movefile && ! isset( $movefile['error'] ) ) {
                    $FileLink = $movefile['url'];
                    $FilePath= $movefile['file'];

                    $name = trim($_REQUEST['name']);
                    $csv_file_name = $_FILES['file']['name'];
                    $csv_dir = $FilePath;
                    $csv_url = $FileLink;
                    $slug = $this->CsvUploadFormSlug($_REQUEST['name']);

                    //multiple insert (v2 code)
                    $file = fopen($FilePath,"r");
                    $fields = fgetcsv($file);
                    fclose($file);
                    $dynamic_table = new \App\Database\BCSI_THECBSI_csv_to_sql_dymanic($slug); 
                    $sql=$dynamic_table->getCreateTableSqlQuary($fields);
                    $dynamic_table->TableCreate($sql);
                    $insert_data = $dynamic_table->TableInsertCsv($FilePath);

                    //insert single (v1 code)
                    // $dynamic_table = new \App\Database\BCSI_THECBSI_csv_to_sql_dymanic($slug);
                    // $columns_name;
                    // $count = 0;
                    // $file = fopen($FilePath,"r");
                    // while(! feof($file))
                    // {
                    //     $count = $count + 1;
                    //     if ($count == 1) {
                    //         $fields = fgetcsv($file);
                    //         $sql=$dynamic_table->getCreateTableSqlQuary($fields);
                    //         $dynamic_table->TableCreate($sql);
                    //         $columns_name = $dynamic_table->TableColumnName();
                    //     }
                    //     else {
                    //         $insert=array();
                    //         $from_csv=fgetcsv($file);
                    //         foreach ($from_csv as $key => $value) {
                    //             $insert[$columns_name[$key]] = $value;
                    //         }
                    //         $dynamic_table->TableInsert($insert);
                    //     }
                    // }
                    // fclose($file);

                    $table_column_user_column['user_header'] = $fields;
                    $table_column_user_column['table_header'] = $dynamic_table->TableColumnName();
                    $Db_insert = array(
                                'name'=>$name,
                                'slug'=>$slug,
                                'csv_file_name'=>$csv_file_name,
                                'csv_dir'=>$csv_dir,
                                'csv_url'=>$csv_url,
                                'table_name'=>$dynamic_table->TableName(),
                                "table_column_user_column" => serialize($table_column_user_column)
                            );
                    $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
                    $wpdb->insert( $tableName , $Db_insert) or die(json_encode(array("status"=>"error","message"=>"Database Error")));

                    $success = json_encode(array('status'=>'success' ,'message'=>"data insert sucessfully" ));
                    echo $success;
                }else{
                    $error = json_encode(array('status'=>'error' ,'message'=>"File upload not working" ));
                    echo $error;
                }
            }else{
                $error = json_encode(array('status'=>'error' ,'message'=>"Please give name field & csv file" ));
                echo $error;
            } 
        } catch (Exception $e) {
            $error = json_encode(array('status'=>'error' ,'message'=> $e->getMessage() ));
            echo $error;
        }

        wp_die();
    }

    public function wp_ajax_CsvUploadFormDeleteSubmit(){
        try {
            global $wpdb;
           
            // $sql = "DROP TABLE IF EXISTS `".$tablename."`";
            // $wpdb->query($sql);

            $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
            $results_from_table = $wpdb->get_row( 
                $wpdb->prepare("SELECT * FROM `{$tableName}` WHERE 	id=%d", $_REQUEST['deleteId']) 
            );
            $sql = "DROP TABLE IF EXISTS `".$results_from_table->table_name."`";
            $wpdb->query($sql) or die(json_encode(array("status"=>"error","message"=>"Error to delete $results_from_table->table_name database ")));

            $wpdb->delete( $tableName , array( 'id'  => $_REQUEST['deleteId'] )) or die(json_encode(array("status"=>"error","message"=>"Database Error")));

            $success = json_encode(array('status'=>'success' ,'message'=>"data delete sucessfully" ));
            echo $success;
        } catch (Exception $e) {
            $error = json_encode(array('status'=>'error' ,'message'=> $e->getMessage() ));
            echo $error;
        }finally {
            wp_die();
        }    
    }
    
    public function CsvUploadFormValidation() {
        if (empty($_REQUEST['name']) ) {
            return false;
        }
        if (empty($_FILES['file']['type'])) {
            return false;
        }
        if ( !in_array($_FILES['file']['type'] , $this->file_ext_support )) {
            return false;
        }
        return true;
    }

    public function CsvUploadFormSlug($value) {
        $slug = trim($value); // trim the string
        $slug= preg_replace('/[^a-zA-Z0-9 -]/','',$slug ); // only take alphanumerical characters, but keep the spaces and dashes too...
        $slug= str_replace(' ','-', $slug); // replace spaces by dashes
        $slug= strtolower($slug);  // make it lowercase

        global $wpdb;
        $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
        $results = $wpdb->get_results( 
            $wpdb->prepare("SELECT count(ID) as total FROM {$tableName} WHERE 	slug=%d", $slug) 
         );
         if ($results[0]->total >= 1) {
            $slug .= "-".$results[0]->total ;
         }
        return $slug;
    }

	
}
