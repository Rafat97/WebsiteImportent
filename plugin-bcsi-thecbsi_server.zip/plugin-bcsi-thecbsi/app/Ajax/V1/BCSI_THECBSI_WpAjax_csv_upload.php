<?php


namespace App\Ajax\V1;


class BCSI_THECBSI_WpAjax_csv_upload
{
    public $file_ext_support = array(
        "text/csv",
        "application/vnd.ms-excel",
    );
	public function action() {
        add_action("wp_ajax_CsvUploadFormSubmit", array( $this, 'CsvUploadFormSubmit' ));
        add_action("wp_ajax_CsvUploadFormDeleteSubmit", array( $this, 'wp_ajax_CsvUploadFormDeleteSubmit' ));
	}

	public function CsvUploadFormSubmit() {
        try {
            global $wpdb;
            if ($this->CsvUploadFormValidation()) {
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                $uploadedfile = $_FILES['file'];
                $upload_overrides = array( 'test_form' => false );
                
                $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
                if ( $movefile && ! isset( $movefile['error'] ) ) {
                    $FileLink = $movefile['url'];
                    $FilePath= $movefile['file'];
                    

                    $name = trim($_REQUEST['name']);
                    $csv_file_name = $_FILES['file']['name'];
                    $csv_dir = $FilePath;
                    $csv_url = $FileLink;
                    $slug = $this->CsvUploadFormSlug($_REQUEST['name']);

                    $file = fopen($FilePath,"r");
                    $fields = fgetcsv($file);
                    fclose($file);

                    $column_name = \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableColumnNameWithoutDynamicField();
                    if (count($column_name) != count($fields) ) {
                        $error = json_encode(array('status'=>'error' ,'message'=>"Sorry !! column number not match. Please Check sample csv format" ));
                        echo $error;
                        exit;
                    }
                    
                    $fields_convert = $fields;
                    $array_diff=array_diff($fields,$column_name);
                    
                    if (count( $array_diff) >= 1) {
                        // heading format by column name
                        foreach ($array_diff as $key => $value) {
                            $slug = trim($value); 
                            $slug= preg_replace('/[^a-zA-Z0-9 -]/','',$slug ); 
                            $slug= str_replace(' ','_', $slug); 
                            $slug= str_replace('-','_', $slug); 
                            $slug= strtolower($slug);  
                            $fields_convert[$key] = $slug;
                        }
                        $array_diff=array_diff($fields_convert,$column_name);
                        if (count( $array_diff) >= 1) {
                            $error = json_encode(array('status'=>'error' ,'message'=>"Wrong Heading format" ));
                            echo $error;
                            exit;
                        }
                    }
                   
                    foreach ($column_name as $key => $value) {
                        if ($column_name[$key] != $fields_convert[$key]) {
                            $error = json_encode(array('status'=>'error' ,'message'=>"Wrong Heading position ($fields_convert[$key] , $column_name[$key])" ));
                            echo $error;
                            exit;
                        }
                    }
                    
                    $table_name = \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableName();
                    $sql = "DROP TABLE IF EXISTS `".$table_name."`";
                    $wpdb->query($sql) or die(json_encode(array("status"=>"error","message"=>"Error to delete $table_name database ")));

                    $table_name = \App\Database\BCSI_THECBSI_csv_upload::TableName();
                    $sql = "DROP TABLE IF EXISTS `".\App\Database\BCSI_THECBSI_csv_upload::TableName()."`";
                    $wpdb->query($sql) or die(json_encode(array("status"=>"error","message"=>"Error to delete $results_from_table->table_name database ")));

                    \App\Database\BCSI_THECBSI_csv_upload::TableCreate();
                    \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableCreate();

                    \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableInsertCsv($csv_dir);
                    
                    $table_column_user_column['user_header'] = $fields;
                    $table_column_user_column['table_header'] = $column_name;
                    $Db_insert = array(
                                'name'=>$name,
                                'slug'=>$slug,
                                'csv_file_name'=>$csv_file_name,
                                'csv_dir'=>$csv_dir,
                                'csv_url'=>$csv_url,
                                'table_name'=>\App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableName(),
                                "table_column_user_column" => serialize($table_column_user_column)
                            );
                    $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
                    $wpdb->insert( $tableName , $Db_insert) or die(json_encode(array("status"=>"error","message"=>"Database Error")));

                    $success = json_encode(array('status'=>'success' ,'message'=>"data insert sucessfully" ));
                    echo $success;
                }else{
                    $error = json_encode(array('status'=>'error' ,'message'=>"File upload not working" ));
                    echo $error;
                }
            }else{
                $error = json_encode(array('status'=>'error' ,'message'=>"Please give name field & csv file" ));
                echo $error;
            } 
        } catch (Exception $e) {
            $error = json_encode(array('status'=>'error' ,'message'=> $e->getMessage() ));
            echo $error;
        }

        wp_die();
    }

    public function wp_ajax_CsvUploadFormDeleteSubmit(){
        try {
            global $wpdb;

            $table_name = \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableName();
            $sql = "DROP TABLE IF EXISTS `".$table_name."`";
            $wpdb->query($sql) or die(json_encode(array("status"=>"error","message"=>"Error to delete $table_name database ")));

            $table_name = \App\Database\BCSI_THECBSI_csv_upload::TableName();
            $sql = "DROP TABLE IF EXISTS `".\App\Database\BCSI_THECBSI_csv_upload::TableName()."`";
            $wpdb->query($sql) or die(json_encode(array("status"=>"error","message"=>"Error to delete $results_from_table->table_name database ")));

            \App\Database\BCSI_THECBSI_csv_upload::TableCreate();
            \App\Database\V1\BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info::TableCreate();

            $success = json_encode(array('status'=>'success' ,'message'=>"data delete sucessfully" ));
            echo $success;
        } catch (Exception $e) {
            $error = json_encode(array('status'=>'error' ,'message'=> $e->getMessage() ));
            echo $error;
        }finally {
            wp_die();
        }    
    }
    
    public function CsvUploadFormValidation() {
        if (empty($_REQUEST['name']) ) {
            return false;
        }
        if (empty($_FILES['file']['type'])) {
            return false;
        }
        if ( !in_array($_FILES['file']['type'] , $this->file_ext_support )) {
            return false;
        }
        return true;
    }

    public function CsvUploadFormSlug($value) {
        $slug = trim($value); // trim the string
        $slug= preg_replace('/[^a-zA-Z0-9 -]/','',$slug ); // only take alphanumerical characters, but keep the spaces and dashes too...
        $slug= str_replace(' ','-', $slug); // replace spaces by dashes
        $slug= strtolower($slug);  // make it lowercase

        global $wpdb;
        $tableName = \App\Database\BCSI_THECBSI_csv_upload::TableName();
        $results = $wpdb->get_results( 
            $wpdb->prepare("SELECT count(ID) as total FROM {$tableName} WHERE 	slug=%d", $slug) 
         );
         if ($results[0]->total >= 1) {
            $slug .= "-".$results[0]->total ;
         }
        return $slug;
    }

	
}
