<?php


namespace App\Ajax;


class BCSI_THECBSI_WpAjax_database_dynamic_data
{
    
	public function action() {
        add_action("wp_ajax_BCSI_plug_DatabaseDynamicDataDelete", array( $this, 'wp_ajax_DatabaseDynamicDataDelete' ));
        add_action("wp_ajax_BCSI_plug_DatabaseDynamicDataEdit", array( $this, 'wp_ajax_DatabaseDynamicDataEdit' ));
	}

	public function wp_ajax_DatabaseDynamicDataDelete() {
        try {
            global $wpdb;
            if (!empty($_REQUEST['tableName']) && !empty($_REQUEST['deletedId'])) {
                $id = $_REQUEST['deletedId'];
                $table = $_REQUEST['tableName'];
                $wpdb->delete( $table, array( 'id' => $id ) );
                $success = json_encode(array('status'=>'success' ,'message'=>"data deleted sucessfully" ));
                echo $success;
            }
            else {
                $error = json_encode(array('status'=>'error' ,'message'=> "required tableName and deletedId"));
                echo $error;
            }
            
        } catch (Exception $e) {
            $error = json_encode(array('status'=>'error' ,'message'=> $e->getMessage() ));
            echo $error;
        }

        wp_die();
    }

    public function wp_ajax_DatabaseDynamicDataEdit() {
        try {
            global $wpdb;

            if (!empty($_REQUEST['tableName']) && !empty($_REQUEST['editedId'])) {

                $editedId = $_REQUEST['editedId'];
                $tableName = $_REQUEST['tableName'];

                $update_data_field = $_REQUEST;
                unset($update_data_field['editedId']);
                unset($update_data_field['action']);
                unset( $update_data_field['tableName']);

                $update = $wpdb->update($tableName, 
                        $update_data_field  , 
                        array('id'=>$editedId ));

                
                if ($update == 0 ) {
                    $error = json_encode(array('status'=>'error' ,'message'=> "data not updated"));
                    echo $error;
                }else{
                    $success = json_encode(array('status'=>'success' ,'message'=>"data update sucessfully" ));
                    echo $success;
                }
                
            }
            else {
                $error = json_encode(array('status'=>'error' ,'message'=> "required tableName and deletedId"));
                echo $error;
            }
            
        } catch (Exception $e) {
            $error = json_encode(array('status'=>'error' ,'message'=> $e->getMessage() ));
            echo $error;
        }

        wp_die();
    }

}
