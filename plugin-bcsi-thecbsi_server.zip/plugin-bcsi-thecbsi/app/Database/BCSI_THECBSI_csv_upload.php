<?php

namespace App\Database;

class BCSI_THECBSI_csv_upload{

    public static function TableName()
	{
		global $wpdb;
		$value = $wpdb->prefix . strtolower('BCSI_THECBSI_PLUG_csv_upload');
		return $value;
    }
    
    public static function TableCreate()
	{
        global $wpdb;
        $tablename = self::TableName();
		$sql = "CREATE TABLE `".$tablename."` (
            `id` bigint(20) NOT NULL AUTO_INCREMENT,
            `slug` text DEFAULT NULL,
            `name` text DEFAULT NULL,
            `table_name` text DEFAULT NULL,
            `table_column_user_column` text DEFAULT NULL,
            `csv_file_name` text DEFAULT NULL,
            `csv_dir` text DEFAULT NULL,
            `csv_url` text DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            dbDelta($sql);
    }
    
    public static function TableDelete()
	{
        global $wpdb;
        $tablename = self::TableName();
        $sql = "DROP TABLE IF EXISTS ".$tablename."";
        $wpdb->query($sql);
        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
	}
}