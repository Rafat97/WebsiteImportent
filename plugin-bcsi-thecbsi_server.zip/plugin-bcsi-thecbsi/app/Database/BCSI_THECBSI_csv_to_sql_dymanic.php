<?php

namespace App\Database;

class BCSI_THECBSI_csv_to_sql_dymanic{

    protected $dynamic_table_prefix = "";

    function __construct($dynamic_table_name) {
        $this->dynamic_table_prefix = $dynamic_table_name;
    }

    public function TableName()
	{
		global $wpdb;
		$value = $wpdb->prefix . strtolower('BCSI_THECBSI_PLUG_csv_datas_'.$this->dynamic_table_prefix);
		return $value;
    }
    
    public function TableCreate($sql_input)
	{
        global $wpdb;
        $tablename = $this->TableName();
    
        $sql = "DROP TABLE IF EXISTS `".$tablename."`";
        $wpdb->query($sql);

        $sql = $sql_input;
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }

    public function getCreateTableSqlQuary($fields=array())
	{
        global $wpdb;
        $tablename = $this->TableName();
        $sql = 
        "CREATE TABLE  `".$tablename."` (
            `id` bigint(20) NOT NULL AUTO_INCREMENT,
        ";
        foreach ($fields as $key => $value) {
            $val = bcsi_thecbsi_convert_slug($value);
            $sql .= "`$val` text DEFAULT NULL,";
        }
        $sql.="`created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        return $sql ;
    }
    
    //v1 code
    public function TableInsert($data_with_column_key)
	{
        global $wpdb;

        $tablename = $this->TableName();
        $data = $data_with_column_key;
        $format = array();
        foreach ($data as $key => $value) {
            array_push($format,"%s");
        }

        $insert = $wpdb->insert($tablename,$data,$format);
        if ($insert != 1) {
            throw new Exception("`$tablename` table  insert not working");
        }
        return $insert;

        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
    }

    //v2 code
    public function TableInsertCsv($csv_path)
	{
        try {
            global $wpdb;

            $tablename = $this->TableName();
            $colm_name=$this->TableColumnName();
            foreach ($colm_name as $key => $value) {
                $colm_name[$key] ="`$tablename`.`$value`";
            }
            $colm = implode(",",$colm_name);
            $csv = $csv_path;
            $file = fopen($csv,"r");
           
            
            if (($file = fopen($csv,"r")) !== FALSE) {
                $sql_insert_data = array();
                $count = 0;
                while(! feof($file))
                {
                    $count = $count + 1;
                    $from_csv=fgetcsv($file);
                    if ($count != 1) {
                        if (!empty($from_csv) && count($from_csv) == count($colm_name ) ) {
                            array_walk($from_csv,'self::_real_escape');
                            $comma_separated = implode("','", $from_csv);
                            $comma_separated = "'".$comma_separated."'";
                            \array_push($sql_insert_data , "($comma_separated)");
                        }
                       
                    }
                }
                fclose($file);
                $batch_of = 1000;
                $batch_array = array_chunk($sql_insert_data, $batch_of);
                foreach ($batch_array as $value) {
                    $sql = "INSERT INTO `$tablename`($colm) VALUES ";
                    $sql .= implode(",",$value) ;

                    $insert  = $wpdb->query($sql);
                    if ($insert == 0) {
                            throw new Exception("`$tablename` table data insert not working");
                            return false;
                    }
                    // echo $sql."<br><br>";
                    // echo count($value);
                }
                return true;
                
                // print_r($batch);
                // echo count($sql_insert_data);
                // $sql .= implode(",",$sql_insert_data) ;
                // echo $sql;
                // $insert  = $wpdb->query($sql);
            
                // echo $sql;
                
            }else {
                throw new Exception("File not found");
            }
        }catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
    }
    
    
    public function TableColumnName()
	{
        global $wpdb;

        $tablename = $this->TableName();
        $cols = $wpdb->get_col("DESC `{$tablename}` ",0);

        \array_splice($cols, 0, 1);
        \array_splice($cols,  count($cols)-1,1);
        
        return $cols ;
        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
	}
	
    public static function _real_escape(&$value)
    {
        global $wpdb;
        $value = trim($value); 
        $value = $wpdb->_real_escape($value); 
    }
    
    public function TableDelete()
	{
        global $wpdb;

        $tablename = $this->TableName();
        $sql = "DROP TABLE IF EXISTS `".$tablename."`";
        $wpdb->query($sql);

        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
	}
}