<?php

namespace App\Database\V1;

class BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info{


    function __construct() {}

    public static function TableName()
	{
		global $wpdb;
		$value = $wpdb->prefix . strtolower('BCSI_THECBSI_PLUG_csv_datas_bcsi_result_user_info');
		return $value;
    }
    
    public static function TableCreate()
	{
        global $wpdb;
        $tablename = self::TableName();
    
        $sql = "DROP TABLE IF EXISTS `".$tablename."`";
        $wpdb->query($sql);

        $sql = "CREATE TABLE `$tablename` (
            `id` bigint(20) NOT NULL AUTO_INCREMENT,
            `first_name` text DEFAULT NULL,
            `last_name` text DEFAULT NULL,
            `city` text DEFAULT NULL,
            `state_or_province` text DEFAULT NULL,
            `country` text DEFAULT NULL,
            `website` text DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }


    //v2 code
    public static function TableInsertCsv($csv_path)
	{
        try {
            global $wpdb;

            $tablename = self::TableName();
            $colm_name = self::TableColumnNameWithoutDynamicField();
            foreach ($colm_name as $key => $value) {
                $colm_name[$key] ="`$tablename`.`$value`";
            }
            $colm = implode(",",$colm_name);
            $csv = $csv_path;
            $file = fopen($csv,"r");
           
            
            if (($file = fopen($csv,"r")) !== FALSE) {
                $sql_insert_data = array();
                $count = 0;
                while(! feof($file))
                {
                    $count = $count + 1;
                    $from_csv=fgetcsv($file);
                    if ($count != 1) {
                        if (!empty($from_csv) && count($from_csv) == count($colm_name ) ) {
                            array_walk($from_csv,'self::_real_escape');
                            $comma_separated = implode("','", $from_csv);
                            $comma_separated = "'".$comma_separated."'";
                            \array_push($sql_insert_data , "($comma_separated)");
                        }
                       
                    }
                }
                fclose($file);
                $batch_of = 1000;
                $batch_array = array_chunk($sql_insert_data, $batch_of);
                foreach ($batch_array as $value) {
                    $sql = "INSERT INTO `$tablename`($colm) VALUES ";
                    $sql .= implode(",",$value) ;
                    // echo "$sql";
                    $insert  = $wpdb->query($sql);
                    if ($insert == 0) {
                            throw new Exception("`$tablename` table data insert not working");
                            return false;
                    }
                    // echo $sql."<br><br>";
                    // echo count($value);
                }
                return true;
                
                // print_r($batch);
                // echo count($sql_insert_data);
                // $sql .= implode(",",$sql_insert_data) ;
                // echo $sql;
                // $insert  = $wpdb->query($sql);
            
                // echo $sql;
                
            }else {
                throw new Exception("File not found");
            }
        }catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
    }

    public static function TableInsertCsvPrepair($csv_path)
	{
        try {
            global $wpdb;

            $tablename = self::TableName();
            $colm_name = self::TableColumnNameWithoutDynamicField();

            $number_of_column_placeholder=array();
            
            foreach ($colm_name as $key => $value) {
                $colm_name[$key] ="`$tablename`.`$value`";
                $number_of_column_placeholder[] = "%s";
            }
            
            $number_of_column_placeholder = implode("','", $number_of_column_placeholder);
            $number_of_column_placeholder = "('".$number_of_column_placeholder."')";
            
            $colm = implode(",",$colm_name);

            $place_holders = array();
            $csv = $csv_path;
            $file = fopen($csv,"r");
           
            
            if (($file = fopen($csv,"r")) !== FALSE) {
                $sql_insert_data = array();
                $count = 0;
                while(! feof($file))
                {
                    $count = $count + 1;
                    $from_csv=fgetcsv($file);
                    if ($count != 1) {
                        if (!empty($from_csv) && count($from_csv) == count($colm_name ) ) { 
                            array_walk($from_csv,'self::_real_escape');
                            $comma_separated = implode("','", $from_csv);
                            $comma_separated = "'".$comma_separated."'";
                            $place_holders[] = $number_of_column_placeholder;
                            \array_push($sql_insert_data , "($comma_separated)");
                        }
                       
                    }
                }
                fclose($file);
                $batch_of = 10;
                $batch_array = array_chunk($sql_insert_data, $batch_of);
                $place_holders_chunk = array_chunk($place_holders, $batch_of);
                foreach ($batch_array as $key=>$value) {
                    $sql = "INSERT INTO `$tablename`($colm) VALUES ";

                    // $query = "INSERT INTO `$tablename` ($colm) VALUES ";
                    // $query .= implode( ', ', $place_holders_chunk[$key]  );

                    // // print_r($value);
                    // echo "<br><br>";
                    // echo $query;
                    // $wpdb->query(
                    //     $wpdb->prepare($query, $value )
                    // );
                    
                    $sql .= implode(",",$value) ;
                    $insert  = $wpdb->query($sql);
                    if ($insert == 0) {
                            throw new Exception("`$tablename` table data insert not working");
                            return false;
                    }
                    // echo $sql."<br><br>";
                    // echo count($value);
                }
                return true;
                
                // print_r($batch);
                // echo count($sql_insert_data);
                // $sql .= implode(",",$sql_insert_data) ;
                // echo $sql;
                // $insert  = $wpdb->query($sql);
            
                // echo $sql;
                
            }else {
                throw new Exception("File not found");
            }
        }catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
    }
    public static function _real_escape(&$value)
    {
        global $wpdb;
        $value = trim($value); 
        $value = $wpdb->_real_escape($value); 
    }
    

    public static function TableColumnNameWithoutDynamicField()
	{
        global $wpdb;

        $tablename = self::TableName();
        $cols = $wpdb->get_col("DESC `{$tablename}` ",0);

        \array_splice($cols, 0, 1);
        \array_splice($cols,  count($cols)-1,1);
        
        return $cols ;
    
    }
    
    public static function TableColumnNameAll()
	{
        global $wpdb;

        $tablename = self::TableName();
        $cols = $wpdb->get_col("DESC `{$tablename}` ",0);
        
        return $cols ;
    
	}

    
    public static function TableDelete()
	{
        global $wpdb;

        $tablename = self::TableName();
        $sql = "DROP TABLE IF EXISTS `".$tablename."`";
        $wpdb->query($sql);

        // require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        // dbDelta($sql);
	}
}