Note: a reference to `MaterialIcons` is intentionally omitted because the
corresponding font is not included in this source.

If you add `MaterialIcons-Extended.ttf` to this directory, you can update
`FontManifest.json` as follows:

```json
[
  {
    "family": "MaterialIcons",
    "fonts": [
      {
        "asset": "MaterialIcons-Extended.ttf"
      }
    ]
  },
  {
    "family": "GoogleSans",
    "fonts": [
      {
        "asset": "GoogleSans-Regular.ttf"
      }
    ]
  },
  {
    "family": "GalleryIcons",
    "fonts": [
      {
        "asset": "GalleryIcons.ttf"
      }
    ]
  }
]
```
