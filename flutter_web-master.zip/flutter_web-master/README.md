**This repository is no longer maintained.**

As of September 10, 2019, Flutter for web development has fully moved
to https://github.com/flutter/flutter. To build web apps using Flutter
[use the standard Flutter SDK][getting started].

You can find the old readme [here](https://github.com/flutter/flutter_web/blob/master/OLD_README.md).

[getting started]: https://flutter.dev/docs/get-started/web
